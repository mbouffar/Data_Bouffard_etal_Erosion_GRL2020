import numpy as np
from Inversions import Inv_leastsquares

def Uncertainty_coeff(d,Ri):
    d  = np.log(d)
    s, = np.shape(d)
    G  = np.zeros((s,2))
    G[:,0] = 1.
    G[:,1] = np.log(Ri)
    #G[:,1] = np.log(Fr)
    #G[:,2] = np.log(P)
    Cd = np.zeros((s,s))
    for i in range(s) :
    #     Cd[i,i] = Mix[i]**2
        Cd[i,i] = 1.;
    
    m = Inv_leastsquares(G,d,Cd)
    a  = np.exp(m[0])
    n  = m[1]
    return a,n 

def Uncertainty_coeff2(d,Ri):
    d  =  d/Ri**(-1.6)
    s, = np.shape(d)
    G  = np.zeros((s,1))
    G[:,0] = 1.
    #G[:,1] = np.log(Ri)
    #G[:,1] = np.log(Fr)
    #G[:,2] = np.log(P)
    Cd = np.zeros((s,s))
    for i in range(s) :
    #     Cd[i,i] = Mix[i]**2
        Cd[i,i] = 1.;
    
    m = Inv_leastsquares(G,d,Cd)
    a  = m[0]
    #n  = m[1]
    return a


def Uncertainty_coeff3(d,Ek,RaC):
    d  = np.log(d)
    s, = np.shape(d)
    G  = np.zeros((s,3))
    G[:,0] = 1.
    G[:,1] = np.log(RaC)
    G[:,2] = np.log(Ek)
    #G[:,1] = np.log(Fr)
    #G[:,2] = np.log(P)
    Cd = np.zeros((s,s))
    for i in range(s) :
    #     Cd[i,i] = Mix[i]**2
        Cd[i,i] = 1.;
    
    m = Inv_leastsquares(G,d,Cd)
    a_all = np.exp(m[0])
    n_RaC = m[1] 
    n_Ek  = m[2]
    return a_all,n_RaC,n_Ek

def Uncertainty_coeff4(d):
    s, = np.shape(d)
    G  = np.zeros((s,1))
    G[:,0] = 1.
    #G[:,1] = np.log(Ri)
    #G[:,1] = np.log(Fr)
    #G[:,2] = np.log(P)
    Cd = np.zeros((s,s))
    for i in range(s) :
    #     Cd[i,i] = Mix[i]**2
        Cd[i,i] = 1.;
    
    m = Inv_leastsquares(G,d,Cd)
    a  = m[0]
    #n  = m[1]
    return a

def Uncertainty_coeff5(d,Ek,RaC,RaT):
    d  = np.log(d)
    s, = np.shape(d)
    G  = np.zeros((s,4))
    G[:,0] = 1.
    G[:,1] = np.log(RaC)
    G[:,2] = np.log(Ek)
    G[:,3] = np.log(RaT)
    #G[:,1] = np.log(Fr)
    #G[:,2] = np.log(P)
    Cd = np.zeros((s,s))
    for i in range(s) :
    #     Cd[i,i] = Mix[i]**2
        Cd[i,i] = 1.;
    
    m = Inv_leastsquares(G,d,Cd)
    a_all = np.exp(m[0])
    n_RaC  = m[1] 
    n_Ek   = m[2]
    n_RaT  = m[3]
    return a_all,n_RaC,n_Ek, n_RaT


def Uncertainty_coeff6(d,RaC):
    d  = np.log(d)
    s, = np.shape(d)
    G  = np.zeros((s,2))
    G[:,0] = 1.
    G[:,1] = np.log(RaC)
    #G[:,1] = np.log(Fr)
    #G[:,2] = np.log(P)
    Cd = np.zeros((s,s))
    for i in range(s) :
    #     Cd[i,i] = Mix[i]**2
        Cd[i,i] = 1.;
    
    m = Inv_leastsquares(G,d,Cd)
    a_all = np.exp(m[0])
    n_RaC  = m[1] 
    return a_all,n_RaC