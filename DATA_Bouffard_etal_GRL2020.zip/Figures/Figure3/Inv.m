function m = Inv(G,d,Cd)
% Fonction qui donne le meilleur modele m au sens des moindres carres pour des donnees d tel que d = Gm
% Cd : matrice de covariance des donnees. La diagonale correspond aux erreurs au carre sur les donnees. 
Cdi = inv(Cd);
A = inv(G'*Cdi*G);
B  = A * G' * Cdi;
m = B * d;