import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from Inversions import Inv_leastsquares
from Uncertainty import Uncertainty_coeff
from Uncertainty import Uncertainty_coeff2
from Uncertainty import Uncertainty_coeff3
from Uncertainty import Uncertainty_coeff4
from Uncertainty import Uncertainty_coeff5
from Uncertainty import Uncertainty_coeff6
# Pat
path = '/Users/maylis/Documents/PostDoc2/ErosionStrat/Manuscript/Manuscrit_essai/Figures/Matlab_Maylis_2020_04_17/Data/'
Erosion_path = path+'ErosionRate_local_fit_4.xlsx'



N = 300

#--------------
#Read data
#--------------
Erosion= pd.read_excel(Erosion_path)

Ek   = np.array(Erosion['Ekman'])
RaT   = np.array(Erosion['RaT'])
RaC   = np.array(Erosion['RaC'])
h0   = np.array(Erosion['h0'])
Re  = np.array(Erosion['Utot'])
Ri0 = RaC/(Re**2.*Ek)
h   = np.array(Erosion['h1'])
dhdt = np.array(Erosion['Dhdt_1'])
RaC_mod = RaC*Ek
RaT_mod = RaT*Ek**2.

#---------------------
# BEST FIT with only Ri
#---------------------

# Best fit with only Ri
d  = np.log(-dhdt/Re)
s, = np.shape(d)
G  = np.zeros((s,2))
G[:,0] = 1.
G[:,1] = np.log(Ri0*(1.-h/h0))
#G[:,1] = np.log(Fr)
#G[:,2] = np.log(P)
Cd = np.zeros((s,s))
for i in range(s) :
#     Cd[i,i] = Mix[i]**2
    Cd[i,i] = 1.;

m = Inv_leastsquares(G,d,Cd)
a     = np.exp(m[0])
n     = m[1]
print a
print n


# Figure

#plt.figure()
#plt.loglog(Ri0,-dhdt/Re)
#plt.show()
#plt.loglog(x_m,y_m,Color_fit,linewidth=LineW_fit)
#plt.errorbar(np.exp(a)*(P**beta)*(Fr**alpha),Mix,\
#             xerr=xerr, yerr=yerr,\
#             fmt = Symbol_P0_001,\
#             mfc=Color_MarkerFace,mec=Color_P0_001,\
#             ms=Symbol_size, mew=SymbolEdge_size,\
#             ecolor=Color_errorbar,elinewidth=LineW_errorbar)
#plt.xlim((0.3,600))
#plt.ylim((0.3,600))
#plt.ylabel('Dimensionless entrained volume, $V_e/V_0$')
#plt.xlabel('$0.019 P^{-0.41} Fr^{1.39}$')



# Dispersion
Ri = Ri0*(1.-h/h0)
a = 29.6
n = - 1.6
y = a*Ri**n
#E = np.sqrt(1./s*np.sum(((-dhdt/Re-y))**2.))/np.mean(y) 
#E = np.sqrt(1./s*np.sum(((-dhdt/Re-y)/(y))**2.)) 
#E = np.sqrt(1./s*np.sum(((np.log(-dhdt/Re)-np.log(y))/np.log(y))**2.)) 
E_Ri = np.sqrt(1./s*np.sum(((np.log(-dhdt/Re)-np.log(y)))**2.))/np.mean(np.log(-dhdt/Re)) 
print('Dispersion with only Ri = ')
print E_Ri


# Uncertainty on Ri exponent
A = []
M = []
for i in range(N) :
    R = np.random.random((s/2))*s
    R = np.round(R)
    R = R.astype(int)-1
    dhdt2 = dhdt[R]
    Re2 = Re[R]
    d2 = -dhdt2/Re2 
    Ri2 = Ri[R]
    a2,n2 = Uncertainty_coeff(d2,Ri2)
    A = A + [a2]
    M = M + [n2]


nm = np.mean(M)
nu = np.sqrt(np.mean((nm-M)**2.))
print('n =')
print(nm)
print('nu =')
print(nu)

# Uncertainty on prefactor
A = []
M = []
for i in range(N) :
    R = np.random.random((s/2))*s
    R = np.round(R)
    R = R.astype(int)-1
    dhdt2 = dhdt[R]
    Re2 = Re[R]
    d2 = -dhdt2/Re2 
    Ri2 = Ri[R]
    a2 = Uncertainty_coeff2(d2,Ri2)
    A = A + [a2]


am = np.mean(A)
au = np.sqrt(np.mean((am-A)**2.))
print('a =')
print(am)
print('au =')
print(au)





#---------------------
# BEST FIT with RaC 
#---------------------


# Best fit with only Ri
d  = np.log(-dhdt/Re/(Ri0*(1.-h/h0))**(-1.6))
s, = np.shape(d)
G  = np.zeros((s,2))
G[:,0] = 1.
G[:,1] = np.log(RaC_mod)
#G[:,1] = np.log(Fr)
#G[:,2] = np.log(P)
Cd = np.zeros((s,s))
for i in range(s) :
#     Cd[i,i] = Mix[i]**2
    Cd[i,i] = 1.;

m = Inv_leastsquares(G,d,Cd)
a_RaC = np.exp(m[0])
n           = -1.6
n_RaC_alone = m[1]


print('a_RaC = ')
print a_RaC
print('n_RaC alone = ')
print(n_RaC_alone)



# Dispersion
Ri = Ri0*(1.-h/h0)
n = - 1.7
y = a_RaC*Ri**n*RaC_mod**n_RaC_alone
#E = np.sqrt(1./s*np.sum(((-dhdt/Re-y))**2.))/np.mean(y) 
#E = np.sqrt(1./s*np.sum(((-dhdt/Re-y)/(y))**2.)) 
#E = np.sqrt(1./s*np.sum(((np.log(-dhdt/Re)-np.log(y))/np.log(y))**2.)) 
E_RiEkRaCRaT = np.sqrt(1./s*np.sum(((np.log(-dhdt/Re)-np.log(y)))**2.))/np.mean(np.log(-dhdt/Re)) 



# Uncertainty on Ekman, RaC and RaT exponent
A     = []
M_RaC = []
for i in range(N) :
    R = np.random.random((s/2))*s
    R = np.round(R)
    R = R.astype(int)-1
    dhdt2 = dhdt[R]
    Re2  = Re[R]
    d2   = -dhdt2/Re2 
    Ri2  = Ri[R]
    d2 = d2/(Ri2**n)
    Ek2  = Ek[R]
    RaC2 = RaC_mod[R]
    RaT2 = RaT_mod[R]
    a_all2,n_RaC2= Uncertainty_coeff6(d2,RaC2)
    A    = A    + [a_all2]
    M_RaC= M_RaC+ [n_RaC2]


nm_RaC = np.mean(M_RaC)
nu_RaC = np.sqrt(np.mean((nm_RaC-M_RaC)**2.))


print('n_RaC alone =')
print(nm_RaC)
print('nu_RaC alone =')
print(nu_RaC)





# Uncertainty on prefactor
A = []
for i in range(N) :
    R = np.random.random((s/2))*s
    R = np.round(R)
    R = R.astype(int)-1
    dhdt2 = dhdt[R]
    Re2 = Re[R]
    d2 = -dhdt2/Re2 
    Ri2 = Ri[R]
    Ek2  = Ek[R]
    RaC2 = RaC_mod[R]
    RaT2 = RaT_mod[R]
    d2 = d2/(Ri2**n*RaC2**n_RaC_alone)
    a2 = Uncertainty_coeff4(d2)
    A = A + [a2]


am = np.mean(A)
au = np.sqrt(np.mean((am-A)**2.))
print('a RaC =')
print(am)
print('au RaC =')
print(au)



#---------------------
# BEST FIT with Ek
#---------------------


# Best fit with only Ri
d  = np.log(-dhdt/Re/(Ri0*(1.-h/h0))**(-1.6))
s, = np.shape(d)
G  = np.zeros((s,2))
G[:,0] = 1.
G[:,1] = np.log(Ek)
#G[:,1] = np.log(Fr)
#G[:,2] = np.log(P)
Cd = np.zeros((s,s))
for i in range(s) :
#     Cd[i,i] = Mix[i]**2
    Cd[i,i] = 1.;

m = Inv_leastsquares(G,d,Cd)
a_Ek = np.exp(m[0])
n           = -1.6
n_Ek_alone = m[1]


print('a_Ek = ')
print a_Ek
print('n_Ek alone = ')
print(n_Ek_alone)



# Uncertainty on Ekman, RaC and RaT exponent
A     = []
M_Ek = []
for i in range(N) :
    R = np.random.random((s/2))*s
    R = np.round(R)
    R = R.astype(int)-1
    dhdt2 = dhdt[R]
    Re2  = Re[R]
    d2   = -dhdt2/Re2 
    Ri2  = Ri[R]
    d2 = d2/(Ri2**n)
    Ek2  = Ek[R]
    RaC2 = RaC_mod[R]
    RaT2 = RaT_mod[R]
    a_all2,n_Ek2= Uncertainty_coeff6(d2,Ek2)
    A    = A    + [a_all2]
    M_Ek= M_Ek+ [n_Ek2]


nm_Ek = np.mean(M_Ek)
nu_Ek = np.sqrt(np.mean((nm_Ek-M_Ek)**2.))


print('n_Ek alone =')
print(nm_Ek)
print('nu_Ek alone =')
print(nu_Ek)










#---------------------
# BEST FIT with RaC and Ek
#---------------------


# Best fit with only Ri
d  = np.log(-dhdt/Re/(Ri0*(1.-h/h0))**(-1.6))
s, = np.shape(d)
G  = np.zeros((s,3))
G[:,0] = 1.
G[:,1] = np.log(RaC_mod)
G[:,2] = np.log(Ek)
#G[:,1] = np.log(Fr)
#G[:,2] = np.log(P)
Cd = np.zeros((s,s))
for i in range(s) :
#     Cd[i,i] = Mix[i]**2
    Cd[i,i] = 1.;

m = Inv_leastsquares(G,d,Cd)
a_all = np.exp(m[0])
n     = -1.6
n_RaC = m[1]
n_Ek  = m[2]

print('a_all = ')
print a_all
print('n_Ek and n_RaC = ')
print(n_Ek,n_RaC)


# Figure

#plt.figure()
#plt.loglog(Ri0,-dhdt/Re)
#plt.show()
#plt.loglog(x_m,y_m,Color_fit,linewidth=LineW_fit)
#plt.errorbar(np.exp(a)*(P**beta)*(Fr**alpha),Mix,\
#             xerr=xerr, yerr=yerr,\
#             fmt = Symbol_P0_001,\
#             mfc=Color_MarkerFace,mec=Color_P0_001,\
#             ms=Symbol_size, mew=SymbolEdge_size,\
#             ecolor=Color_errorbar,elinewidth=LineW_errorbar)
#plt.xlim((0.3,600))
#plt.ylim((0.3,600))
#plt.ylabel('Dimensionless entrained volume, $V_e/V_0$')
#plt.xlabel('$0.019 P^{-0.41} Fr^{1.39}$')



# Dispersion
Ri = Ri0*(1.-h/h0)
n = - 1.6
y = a_all*Ri**n*Ek**n_Ek*RaC_mod**n_RaC
#E = np.sqrt(1./s*np.sum(((-dhdt/Re-y))**2.))/np.mean(y) 
#E = np.sqrt(1./s*np.sum(((-dhdt/Re-y)/(y))**2.)) 
#E = np.sqrt(1./s*np.sum(((np.log(-dhdt/Re)-np.log(y))/np.log(y))**2.)) 
E_RiEkRaC = np.sqrt(1./s*np.sum(((np.log(-dhdt/Re)-np.log(y)))**2.))/np.mean(np.log(-dhdt/Re)) 
print('Dispersion with Ek and RaC = ')
print E_RiEkRaC


# Uncertainty on Ekman and RaC exponent
A    = []
M_Ek = []
M_RaC = []
for i in range(N) :
    R = np.random.random((s/2))*s
    R = np.round(R)
    R = R.astype(int)-1
    dhdt2 = dhdt[R]
    Re2  = Re[R]
    d2   = -dhdt2/Re2 
    Ri2  = Ri[R]
    d2 = d2/(Ri2**n)
    Ek2  = Ek[R]
    RaC2 = RaC_mod[R]
    a_all2,n_RaC2,n_Ek2 = Uncertainty_coeff3(d2,Ek2,RaC2)
    A    = A    + [a_all2]
    M_Ek = M_Ek + [n_Ek2]
    M_RaC= M_RaC+ [n_RaC2]


nm_Ek  = np.mean(M_Ek)
nm_RaC = np.mean(M_RaC)
nu_Ek  = np.sqrt(np.mean((nm_Ek -M_Ek )**2.))
nu_RaC = np.sqrt(np.mean((nm_RaC-M_RaC)**2.))
print('n_Ek =')
print(nm_Ek)
print('nu_Ek =')
print(nu_Ek)

print('n_RaC =')
print(nm_RaC)
print('nu_RaC =')
print(nu_RaC)

# Uncertainty on prefactor
A = []
for i in range(N) :
    R = np.random.random((s/2))*s
    R = np.round(R)
    R = R.astype(int)-1
    dhdt2 = dhdt[R]
    Re2 = Re[R]
    d2 = -dhdt2/Re2 
    Ri2 = Ri[R]
    Ek2  = Ek[R]
    RaC2 = RaC_mod[R]
    d2 = d2/(Ri2**n*Ek2**n_Ek*RaC2**n_RaC)
    a2 = Uncertainty_coeff4(d2)
    A = A + [a2]


am = np.mean(A)
au = np.sqrt(np.mean((am-A)**2.))
print('a_all =')
print(am)
print('au all =')
print(au)



#---------------------
# BEST FIT with RaC, RaT and Ek
#---------------------


# Best fit with only Ri
d  = np.log(-dhdt/Re/(Ri0*(1.-h/h0))**(-1.7))
s, = np.shape(d)
G  = np.zeros((s,4))
G[:,0] = 1.
G[:,1] = np.log(RaC_mod)
G[:,2] = np.log(Ek)
G[:,3] = np.log(RaT_mod)
#G[:,1] = np.log(Fr)
#G[:,2] = np.log(P)
Cd = np.zeros((s,s))
for i in range(s) :
#     Cd[i,i] = Mix[i]**2
    Cd[i,i] = 1.;

m = Inv_leastsquares(G,d,Cd)
a_all = np.exp(m[0])
n     = -1.6
n_RaC  = m[1]
n_Ek   = m[2]
n_RaT  = m[3]

print('a_all = ')
print a_all
print('n_Ek, n_RaC and n_RaT = ')
print(n_Ek,n_RaC,n_RaT)


# Figure

#plt.figure()
#plt.loglog(Ri0,-dhdt/Re)
#plt.show()
#plt.loglog(x_m,y_m,Color_fit,linewidth=LineW_fit)
#plt.errorbar(np.exp(a)*(P**beta)*(Fr**alpha),Mix,\
#             xerr=xerr, yerr=yerr,\
#             fmt = Symbol_P0_001,\
#             mfc=Color_MarkerFace,mec=Color_P0_001,\
#             ms=Symbol_size, mew=SymbolEdge_size,\
#             ecolor=Color_errorbar,elinewidth=LineW_errorbar)
#plt.xlim((0.3,600))
#plt.ylim((0.3,600))
#plt.ylabel('Dimensionless entrained volume, $V_e/V_0$')
#plt.xlabel('$0.019 P^{-0.41} Fr^{1.39}$')



# Dispersion
Ri = Ri0*(1.-h/h0)
n = - 1.6
y = a_all*Ri**n*Ek**n_Ek*RaC_mod**n_RaC*RaT_mod**n_RaT
#E = np.sqrt(1./s*np.sum(((-dhdt/Re-y))**2.))/np.mean(y) 
#E = np.sqrt(1./s*np.sum(((-dhdt/Re-y)/(y))**2.)) 
#E = np.sqrt(1./s*np.sum(((np.log(-dhdt/Re)-np.log(y))/np.log(y))**2.)) 
E_RiEkRaCRaT = np.sqrt(1./s*np.sum(((np.log(-dhdt/Re)-np.log(y)))**2.))/np.mean(np.log(-dhdt/Re)) 
print('Dispersion with Ek and RaC = ')
print E_RiEkRaCRaT


# Uncertainty on Ekman, RaC and RaT exponent
A     = []
M_Ek  = []
M_RaC = []
M_RaT = []
for i in range(N) :
    R = np.random.random((s/2))*s
    R = np.round(R)
    R = R.astype(int)-1
    dhdt2 = dhdt[R]
    Re2  = Re[R]
    d2   = -dhdt2/Re2 
    Ri2  = Ri[R]
    d2 = d2/(Ri2**n)
    Ek2  = Ek[R]
    RaC2 = RaC_mod[R]
    RaT2 = RaT_mod[R]
    a_all2,n_RaC2,n_Ek2,n_RaT2 = Uncertainty_coeff5(d2,Ek2,RaC2,RaT2)
    A    = A    + [a_all2]
    M_Ek = M_Ek + [n_Ek2]
    M_RaC= M_RaC+ [n_RaC2]
    M_RaT= M_RaT+ [n_RaT2]


nm_Ek  = np.mean(M_Ek)
nm_RaC = np.mean(M_RaC)
nm_RaT = np.mean(M_RaT)
nu_Ek  = np.sqrt(np.mean((nm_Ek -M_Ek )**2.))
nu_RaC = np.sqrt(np.mean((nm_RaC-M_RaC)**2.))
nu_RaT = np.sqrt(np.mean((nm_RaT-M_RaT)**2.))
print('n_Ek =')
print(nm_Ek)
print('nu_Ek =')
print(nu_Ek)

print('n_RaC =')
print(nm_RaC)
print('nu_RaC =')
print(nu_RaC)

print('n_RaT =')
print(nm_RaT)
print('nu_RaT =')
print(nu_RaT)

# Uncertainty on prefactor
A = []
for i in range(N) :
    R = np.random.random((s/2))*s
    R = np.round(R)
    R = R.astype(int)-1
    dhdt2 = dhdt[R]
    Re2 = Re[R]
    d2 = -dhdt2/Re2 
    Ri2 = Ri[R]
    Ek2  = Ek[R]
    RaC2 = RaC_mod[R]
    RaT2 = RaT_mod[R]
    d2 = d2/(Ri2**n*Ek2**n_Ek*RaC2**n_RaC*RaT2**n_RaT)
    a2 = Uncertainty_coeff4(d2)
    A = A + [a2]


am = np.mean(A)
au = np.sqrt(np.mean((am-A)**2.))
print('a all =')
print(am)
print('au all =')
print(au)
