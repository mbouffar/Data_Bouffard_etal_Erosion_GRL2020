import numpy as np   
import matplotlib.pyplot as plt

#matplotlib.rc('xtick', labelsize=18)     
#matplotlib.rc('ytick', labelsize=18)
plt.rcParams["font.family"] = "Times New Roman"
plt.rcParams['mathtext.fontset'] = u'dejavuserif'

def EfficiencyFunction(P,Z,h0_R,H_R,Drho,a1,a2,a3) : 
    # Mixing efficiency = Mixing energy / total energy
    eps = P * h0_R / (2.*Z) * (a1*P**(a2)*Z**(a3))/(1+H_R/(Z*Drho*2.))
    return eps


# Best fit from experiments Landeau et al 2016
a1 = 1.13
a2 = -0.34
a3 = 0.89
# Best fit from experiment if fit on V/V0-1
#a1 = 0.68
#a2 = -0.43
#a3 = 0.89



#----------------------------
# Value of mixing efficiency 
# eps in experiments
#----------------------------

P = np.arange(0.001,1.,0.001)
H_R = 5./2.9
h0_R = 4./3.*3.14*(2.9/25.5)**2.
rho_l_u = 1000./820.
rho_u_r = (P+1.)/(P+rho_l_u)
Drho = 1. - rho_u_r


# Z = 1
Z = 1.
eps = EfficiencyFunction(P,Z,h0_R,H_R,Drho,a1,a2,a3)


plt.figure(1)
plt.loglog(P,eps,'tab:orange')
plt.show()

# Z = 2


Z = 2.
eps = EfficiencyFunction(P,Z,h0_R,H_R,Drho,a1,a2,a3)


plt.figure(1)
plt.loglog(P,eps,'tab:blue')
plt.show()




# Z = 4

Z = 4.
eps = EfficiencyFunction(P,Z,h0_R,H_R,Drho,a1,a2,a3)


plt.figure(1)
plt.loglog(P,eps, 'tab:red')
plt.xlabel('Density difference ratio')
plt.ylabel('Mixing efficiency')
plt.show()





#----------------------------
# Value of mixing efficiency 
# eps for Earth-like parameters
#----------------------------


P = 0.04 #2%
gamma = np.arange(0.02,1.,0.001)

Rimp_Rc =  gamma**(1./3.)
Z = 1./Rimp_Rc
H_R = 2.
h0_R = 1./3.*(Rimp_Rc)**2.
rho_l_u = 2.
rho_u_r = (P+1.)/(P+rho_l_u)
Drho = 1. - rho_u_r


eps = EfficiencyFunction(P,Z,h0_R,H_R,Drho,a1,a2,a3)


plt.figure(2)
plt.loglog(gamma,eps, 'tab:red',linewidth=2,label=r'$2\%$')
plt.show()





P = 0.02 #1%
gamma = np.arange(0.02,1.,0.001)

Rimp_Rc =  gamma**(1./3.)
Z = 1./Rimp_Rc
H_R = 2.
h0_R = 1./3.*(Rimp_Rc)**2.
rho_l_u = 2.
rho_u_r = (P+1.)/(P+rho_l_u)
Drho = 1. - rho_u_r


eps = EfficiencyFunction(P,Z,h0_R,H_R,Drho,a1,a2,a3)

plt.figure(2)
plt.loglog(gamma,eps, 'tab:orange',linewidth=2,label=r'$1\%$')
plt.show()




P = 0.002 #10%
gamma = np.arange(0.02,1.,0.001)

Rimp_Rc =  gamma**(1./3.)
Z = 1./Rimp_Rc
H_R = 2.
h0_R = 1./3.*(Rimp_Rc)**2.
rho_l_u = 2.
rho_u_r = (P+1.)/(P+rho_l_u)
Drho = 1. - rho_u_r


eps = EfficiencyFunction(P,Z,h0_R,H_R,Drho,a1,a2,a3)

plt.figure(2)
plt.loglog(gamma,eps, 'tab:blue',linewidth=2,label=r'$0.1\%$')
plt.xlabel(r'Impactor-to-target mass ratio',fontsize=18)
plt.ylabel(r'Mixing efficiency',fontsize=18)
plt.legend(fontsize=15, loc=2,facecolor='white', framealpha=0)
plt.xlim((0.02,1))
plt.ylim((0.0001,0.01))
plt.show()

plt.savefig('EfficiencyEarth.pdf', bbox_inches = 'tight' )