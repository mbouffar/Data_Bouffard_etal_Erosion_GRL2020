function gamma = ConPower_2(x,f)
%From Aubert et al. 2009
%f = input('enter fraction of chemical buoyancy')
%x = input('enter aspect ratio ri/ro')
gamma = 3/2*(1-x)^2/(1-x^3)*...
        (f*(3/5*(1-x^5)/(1-x^3)-x^2)...
         +(1-f)*(1-3/5*(1-x^5)/(1-x^3)));
     
     
     