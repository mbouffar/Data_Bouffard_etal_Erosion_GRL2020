function [] = plot_RossbyFit_1 ()

%==========================================
% Commons
%==========================================

cd ../../
SetFigureDefaults_2
cd ./FiguresSupplementary/RichardsonFit/


f = figure(1)

%--------------------
% INPUT
%--------------------



%--------------------
% READ DATA
%--------------------
m = 1 %if m = 1 U using Mathieu's data. if m = 2, U using my data
if m == 1
    DATA = define_data ();
    ndata = length(DATA(:,9));
    Ek = DATA(:,2);
    RaT = DATA(:,3);
    RaC = DATA(:,4);
    RaC_mod = RaC.*Ek;
    RaT_mod = RaT.*Ek.^2;
    
    Re   = DATA(:,6);
    Ri0   = RaC./(Re.^2)./Ek;
    Ro = Re.*Ek;
    
else
    Erosion = xlsread('ErosionRate_local_fit_4.xlsx')
    Ek = Erosion(:,1);
    RaT = Erosion(:,2);
    RaC = Erosion(:,3);
    RaC_mod = RaC.*Ek;
    RaT_mod = RaT.*Ek.^2;
    h0 = Erosion(:,4);
    n = 2; % n=1 Ri0 in convective region, n=2 Ri0 in full shell, n=3 Ri0 based on poloidal energy
    if n == 1
        Re   = Erosion(:,11);
        Re_u = Erosion(:,12);
        Ri0   = RaC./(Re.^2)./Ek;
        Ri0_sd = 2.*Ri0.*Re_u./Re;
    elseif n==2
        Re   = Erosion(:,13);
        Re_u = Erosion(:,14);
        Ri0   = RaC./(Re.^2)./Ek;
        Ri0_sd = 2.*Ri0.*Re_u./Re;
    elseif n==3
        Re   = Erosion(:,15);
        Re_u = Erosion(:,16);
        Ri0   = RaC./(Re.^2)./Ek;
        Ri0_sd = 2.*Ri0.*Re_u./Re;
    end
    
    Ro   = Re.*Ek;
    Ro_u = Ro.*Re_u./Re;
   
    
end

%==========================================
% Scaling law
%==========================================

%--------------------
% BEST FIT
%--------------------


%Geometric correction 
%ri_eff = 1./(1/0.1-0.2*(1/0.1-1));
%gamma = ConPower_2(ri_eff,0);
%gamma = ConPower_2(0.1,0);
%Q = 1-(1-(1-0.2*(1-0.1)).^3);
%D = 1-0.2;
%RaT_mod = RaT_mod.*(Q/D.^4);


gamma = ConPower_2(0.1,0);
V_conv_tot = ((1-(0.2*(1-0.1))).^3-0.1^3)/(1-0.1^3);
c = sqrt(V_conv_tot);
p_conv = gamma.*RaT_mod;
Ro = Ro/c;


% With RaC

d = log(Ro);
G = zeros(length(d),3);
G(:,1) = 1;
G(:,2) = log(p_conv);
G(:,3) = log(RaC_mod);
for i = 1 : length(d)
    %Cd(i,i) = (d(i)).^2;
    Cd(i,i) = 1;
end
m = Inv(G,d,Cd);
a = exp(m(1));
alpha = m(2);
beta = m(3);
%alpha_best = alpha;
%a_best = a;
beta
alpha
ym2 = a.*p_conv.^(alpha).*RaC_mod.^(beta);


%Without RaC
d = log(Ro);
G = zeros(length(d),2);
G(:,1) = 1;
G(:,2) = log(p_conv);
for i = 1 : length(d)
    %Cd(i,i) = (d(i)).^2;
    Cd(i,i) = 1;
end
m = Inv(G,d,Cd);
a = exp(m(1));
alpha = m(2);
alpha_best = alpha;
a_best = a;
ym = a.*p_conv.^(alpha);


%--------------------
% PLOT DATA
%--------------------

Ek_values = [3e-4, 1e-4, 3e-5, 1e-5];
MarkerEk = [MarkerE1, MarkerE2, MarkerE3, MarkerE4];
Nvalues = size(Ek_values);
Nvalues = Nvalues(2);

for i_Ek = 1:Nvalues
    %X = find((Ro<1e-2)&(Ro>5e-3))
    X = find(Ek==Ek_values(i_Ek))
    %X = find((Re<=100)&(Re>=50))
    %X = find((N_Omega_2>=1)&(N_Omega_2<=5))
    %X = find((Ro<1e-2)&(Ro>5e-3))
    
    p_Ek(i_Ek) = loglog(p_conv(X),Ro(X),MarkerEk(i_Ek),...
        'MarkerSize',Markersize_loglog,...
        'MarkerEdgeColor',c_markeredge,...
        'MarkerFaceColor',c_RegimeErosion,'LineWidth',MarkerLinewidth)
    hold on
    
end


%--------------------
% SCALING AUBERT ET AL 2009
%--------------------

p_A2009 = [-9:0.01:-1];
p_A2009 = 10.^(p_A2009);
yA2009min = 0.69.*p_A2009.^(0.42);
yA2009    = 1.31.*p_A2009.^(0.42);
yA2009max = 2.49.*p_A2009.^(0.42);
loglog(p_A2009,yA2009,'k-','LineWidth',1)
loglog(p_A2009,yA2009min,'k--','LineWidth',1)  
loglog(p_A2009,yA2009max,'k--','LineWidth',1)

% X = find(Ek==1e-4)
% p2 = loglog(Ri0(X).*(1-hav(X)./h0(X)),dhdt(X)./Re(X),MarkerE1,...
%     'MarkerSize',Markersize_loglog,...
%     'MarkerEdgeColor',c_markeredge,...
%     'MarkerFaceColor',c_RegimeErosion,'LineWidth',MarkerLinewidth)
%
%
% %X = find(Ro>=1e-2)
% X = find(Ek==3e-5)
% %X = find(Re>=100)
% %X = find(N_Omega_2>=5)
% hold on
% p3 = loglog(Ri0(X).*(1-hav(X)./h0(X)),dhdt(X)./Re(X),MarkerE3,...
%     'MarkerSize',Markersize_loglog,...
%     'MarkerEdgeColor',c_markeredge,...
%     'MarkerFaceColor',c_RegimeErosion,'LineWidth',MarkerLinewidth)
%
% %X = find(Ro>=1e-2)
% X = find(Ek==1e-5)
% %X = find(Re>=100)
% %X = find(N_Omega_2>=5)
% hold on
% p4 = loglog(Ri0(X).*(1-hav(X)./h0(X)),dhdt(X)./Re(X),MarkerE4,...
%     'MarkerSize',Markersize_loglog,...
%     'MarkerEdgeColor',c_markeredge,...
%     'MarkerFaceColor',c_RegimeErosion,'LineWidth',MarkerLinewidth)
%
%






%
%
%
%
%
%
%
%
% x_u = Ri0(X).*(1-hav(X)./h0(X)).*sqrt((Ri0_sd(X)./Ri0(X)).^2+(hsd(X)./hav(X)).^2);
% y_ul = dhdt(X)./Re(X).*sqrt((dhdt_ul(X)./dhdt(X)).^2+(Re_u(X)./Re(X)).^2);
% y_ur = dhdt(X)./Re(X).*sqrt((dhdt_ur(X)./dhdt(X)).^2+(Re_u(X)./Re(X)).^2);
% er = errorbar(Ri0(X).*(1-hav(X)./h0(X)),dhdt(X)./Re(X),y_ul,y_ur,x_u,x_u,MarkerE2,...
%     'CapSize',ErrorCap,...
%     'MarkerSize',Markersize_loglog,...
%     'MarkerEdgeColor',c_markeredge,...
%     'MarkerFaceColor',c_RegimeErosion,'LineWidth',MarkerLinewidth);
% er.Color = c_error;
% hold on
% p1 = loglog(Ri0(X).*(1-hav(X)./h0(X)),dhdt(X)./Re(X),MarkerE2,...
%     'MarkerSize',Markersize_loglog,...
%     'MarkerEdgeColor',c_markeredge,...
%     'MarkerFaceColor',c_RegimeErosion,'LineWidth',MarkerLinewidth)
%
%
%
%
%
%
%
%
%
%
%
%
%
%
%
%
%
% %X = find((Ro<1e-2)&(Ro>5e-3))
% X = find(Ek==3e-4)
% %X = find((Re<=100)&(Re>=50))
% %X = find((N_Omega_2>=1)&(N_Omega_2<=5))
% x_u = Ri0(X).*(1-hav(X)./h0(X)).*sqrt((Ri0_sd(X)./Ri0(X)).^2+(hsd(X)./hav(X)).^2);
% y_ul = dhdt(X)./Re(X).*sqrt((dhdt_ul(X)./dhdt(X)).^2+(Re_u(X)./Re(X)).^2);
% y_ur = dhdt(X)./Re(X).*sqrt((dhdt_ur(X)./dhdt(X)).^2+(Re_u(X)./Re(X)).^2);
% er = errorbar(Ri0(X).*(1-hav(X)./h0(X)),dhdt(X)./Re(X),y_ul,y_ur,x_u,x_u,MarkerE2,...
%     'CapSize',ErrorCap,...
%     'MarkerSize',Markersize_loglog,...
%     'MarkerEdgeColor',c_markeredge,...
%     'MarkerFaceColor',c_RegimeErosion,'LineWidth',MarkerLinewidth);
% er.Color = c_error;
% hold on
% p1 = loglog(Ri0(X).*(1-hav(X)./h0(X)),dhdt(X)./Re(X),MarkerE2,...
%     'MarkerSize',Markersize_loglog,...
%     'MarkerEdgeColor',c_markeredge,...
%     'MarkerFaceColor',c_RegimeErosion,'LineWidth',MarkerLinewidth)
%
% X = find(Ek==1e-4)
% %X = find(Ro<=5e-3)
% %X = find(Re<=50)
% %X = find(N_Omega_2<=1)
% x_u = Ri0(X).*(1-hav(X)./h0(X)).*sqrt((Ri0_sd(X)./Ri0(X)).^2+(hsd(X)./hav(X)).^2);
% y_ul = dhdt(X)./Re(X).*sqrt((dhdt_ul(X)./dhdt(X)).^2+(Re_u(X)./Re(X)).^2);
% y_ur = dhdt(X)./Re(X).*sqrt((dhdt_ur(X)./dhdt(X)).^2+(Re_u(X)./Re(X)).^2);
% er = errorbar(Ri0(X).*(1-hav(X)./h0(X)),dhdt(X)./Re(X),y_ul,y_ur,x_u,x_u,MarkerE1,...
%     'CapSize',ErrorCap,...
%     'MarkerSize',Markersize_loglog,...
%     'MarkerEdgeColor',c_markeredge,...
%     'MarkerFaceColor',c_RegimeErosion,'LineWidth',MarkerLinewidth);
% er.Color = c_error;
% hold on
% p2 = loglog(Ri0(X).*(1-hav(X)./h0(X)),dhdt(X)./Re(X),MarkerE1,...
%     'MarkerSize',Markersize_loglog,...
%     'MarkerEdgeColor',c_markeredge,...
%     'MarkerFaceColor',c_RegimeErosion,'LineWidth',MarkerLinewidth)
%
%
% %X = find(Ro>=1e-2)
% X = find(Ek==3e-5)
% %X = find(Re>=100)
% %X = find(N_Omega_2>=5)
% x_u = Ri0(X).*(1-hav(X)./h0(X)).*sqrt((Ri0_sd(X)./Ri0(X)).^2+(hsd(X)./hav(X)).^2);
% y_ul = dhdt(X)./Re(X).*sqrt((dhdt_ul(X)./dhdt(X)).^2+(Re_u(X)./Re(X)).^2);
% y_ur = dhdt(X)./Re(X).*sqrt((dhdt_ur(X)./dhdt(X)).^2+(Re_u(X)./Re(X)).^2);
% er = errorbar(Ri0(X).*(1-hav(X)./h0(X)),dhdt(X)./Re(X),y_ul,y_ur,x_u,x_u,MarkerE3,...
%     'CapSize',ErrorCap,...
%     'MarkerSize',Markersize_loglog,...
%     'MarkerEdgeColor',c_markeredge,...
%     'MarkerFaceColor',c_RegimeErosion,'LineWidth',MarkerLinewidth);
% er.Color = c_error;
% hold on
% p3 = loglog(Ri0(X).*(1-hav(X)./h0(X)),dhdt(X)./Re(X),MarkerE3,...
%     'MarkerSize',Markersize_loglog,...
%     'MarkerEdgeColor',c_markeredge,...
%     'MarkerFaceColor',c_RegimeErosion,'LineWidth',MarkerLinewidth)
%
% %X = find(Ro>=1e-2)
% X = find(Ek==1e-5)
% %X = find(Re>=100)
% %X = find(N_Omega_2>=5)
% x_u = Ri0(X).*(1-hav(X)./h0(X)).*sqrt((Ri0_sd(X)./Ri0(X)).^2+(hsd(X)./hav(X)).^2);
% y_ul = dhdt(X)./Re(X).*sqrt((dhdt_ul(X)./dhdt(X)).^2+(Re_u(X)./Re(X)).^2);
% y_ur = dhdt(X)./Re(X).*sqrt((dhdt_ur(X)./dhdt(X)).^2+(Re_u(X)./Re(X)).^2);
% er = errorbar(Ri0(X).*(1-hav(X)./h0(X)),dhdt(X)./Re(X),y_ul,y_ur,x_u,x_u,MarkerE4,...
%     'CapSize',ErrorCap,...
%     'MarkerSize',Markersize_loglog,...
%     'MarkerEdgeColor',c_markeredge,...
%     'MarkerFaceColor',c_RegimeErosion,'LineWidth',MarkerLinewidth);
% er.Color = c_error;
% hold on
% p3 = loglog(Ri0(X).*(1-hav(X)./h0(X)),dhdt(X)./Re(X),MarkerE4,...
%     'MarkerSize',Markersize_loglog,...
%     'MarkerEdgeColor',c_markeredge,...
%     'MarkerFaceColor',c_RegimeErosion,'LineWidth',MarkerLinewidth)
%



xlabel('Convective power, $p$','Interpreter',Inter,'FontSize',FontsizeX)
ylabel('$Ro_c$','Interpreter',Inter,'FontSize',FontsizeY)
set(gca,'FontSize',FontsizeInFig)
%txt1 = ['$y = (' num2str(a_best) ') x^{' num2str(alpha_best) '}$'];
%text(3e1,0.2,txt1,'Interpreter','latex','FontSize',15)


l = legend([p_Ek p_Ek p_Ek p_Ek],'$E=3\times 10^{-4}$','$E=10^{-4}$','$E=3\times10^{-5}$','$E=10^{-5}$','Location','northwest')
set(l, 'interpreter', Inter,'FontSize',FontsizeInFig)


axis([1e-9 0.1 1e-4 1])
box on;
pbaspect([1 1 1]);
txt1 = ['\textbf{b}'];
text(10,3,txt1,'Interpreter','latex','FontSize',FontsizeInFig)
set(f,'PaperSize',[FigSize2(3) FigSize2(4)],'PaperUnits','points');
set(f,'Position',FigSize2);
a_best
alpha_best
print(f,'Figure_RossbyScaling.pdf','-dpdf');
%close all;

end
