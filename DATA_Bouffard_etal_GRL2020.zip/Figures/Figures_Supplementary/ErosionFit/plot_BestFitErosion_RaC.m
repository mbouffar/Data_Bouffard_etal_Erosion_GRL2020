function [] = plot_fig3_ML_fit_4 ()

%==========================================
% Commons
%==========================================

cd ../../
SetFigureDefaults_2
cd ./FiguresSupplementary/ErosionFit/


f = figure(1)

%==========================================
% Scaling law
%==========================================
% INPUT
m = 1 ; % Choose data sets to consider. If m = 1 : first measurement for each simulation only,
%if m = 2 second measurement only, if m=3 two measurements per simulation


%--------------------
% READ DATA
%--------------------
Erosion = xlsread('../../Data/ErosionRate_local_fit_4.xlsx')
Ek = Erosion(:,1);
RaT = Erosion(:,2);
RaC = Erosion(:,3);
h0 = Erosion(:,4);
n = 2; % n=1 Ri0 in convective region, n=2 Ri0 in full shell, n=3 Ri0 based on poloidal energy
if n == 1
    Re   = Erosion(:,11);
    Re_u = Erosion(:,12);
    Ri0   = (RaC)./((Re).^2)./Ek;
    Ri0_sd = Erosion(:,6);
elseif n==2
    Re   = Erosion(:,13);
    Re_u = Erosion(:,14);
    Ri0   = (RaC)./((Re).^2)./Ek;
    Ri0_sd = Erosion(:,8);
elseif n==3
    Re   = Erosion(:,15);
    Re_u = Erosion(:,16);
    Ri0   = (RaC)./((Re).^2)./Ek;
    Ri0_sd = Erosion(:,10);
end

hsd = Erosion(:,18);
h1 = Erosion(:,17);
dhdt_1   = -Erosion(:,19);
dhdt_1_beta_min   =- Erosion(:,20);
dhdt_1_beta_max   =- Erosion(:,21);
dhdt_1_CI_min   = -Erosion(:,22);
dhdt_1_CI_max   = -Erosion(:,23);
dhdt_1_ul = dhdt_1 - min(dhdt_1_CI_min,dhdt_1_beta_min);
dhdt_1_ur =-dhdt_1 + max(dhdt_1_CI_max,dhdt_1_beta_max);


h2 = Erosion(:,24);
dhdt_2   = -Erosion(:,26);
dhdt_2_beta_min   = -Erosion(:,27);
dhdt_2_beta_max   = -Erosion(:,28);
dhdt_2_CI_min   = -Erosion(:,29);
dhdt_2_CI_max   = -Erosion(:,30);
dhdt_2_ul = dhdt_2 - min(dhdt_2_CI_min,dhdt_2_beta_min);
dhdt_2_ur =-dhdt_2 + max(dhdt_2_CI_max,dhdt_2_beta_max);


N_Omega_2 = RaC.*Ek./h0;
Ro = Ek.*Re;


if m == 1 % One measurement per simulation, first one
    
    dhdt = dhdt_1;
    hav = h1;
    dhdt_beta_min = dhdt_1_beta_min;
    dhdt_beta_max = dhdt_1_beta_max;
    dhdt_CI_min = dhdt_1_CI_min;
    dhdt_CI_max = dhdt_1_CI_max;
    dhdt_ul = dhdt_1_ul;
    dhdt_ur = dhdt_1_ur;
    
elseif m == 2  % One measurement per simulation, second one
    dhdt = dhdt_2;
    hav = h2;
    dhdt_beta_min = dhdt_2_beta_min;
    dhdt_beta_max = dhdt_2_beta_max;
    dhdt_CI_min = dhdt_2_CI_min;
    dhdt_CI_max = dhdt_2_CI_max;
    dhdt_ul = dhdt_2_ul;
    dhdt_ur = dhdt_2_ur;
elseif m == 3    %Two measurements per simulation
    Ek = [Ek;Ek];
    RaC = [RaC;RaC];
    RaT = [RaT;RaT];
    hav = [h1;h2]
    dhdt = [dhdt_1;dhdt_2];
    dhdt_beta_min = [dhdt_1_beta_min;dhdt_2_beta_min];
    dhdt_beta_max = [dhdt_1_beta_max;dhdt_2_beta_max];
    dhdt_CI_min = [dhdt_1_CI_min;dhdt_2_CI_min];
    dhdt_CI_max = [dhdt_1_CI_max;dhdt_2_CI_max];
    dhdt_ul = [dhdt_1_ul;dhdt_2_ul];
    dhdt_ur = [dhdt_1_ur;dhdt_2_ur];
    
    Re   = [Re;Re];
    Re_u=[Re_u;Re_u];
    Ri0   = [Ri0;Ri0];
    Ri0_sd  = [Ri0_sd;Ri0_sd];
    h0 = [h0;h0];
    hsd = [hsd;hsd];
    N_Omega_2 = [N_Omega_2;N_Omega_2];
    Ro = [Ro;Ro];
end

%--------------------
% BEST FIT
%--------------------

% With only Richardson
d = log(dhdt./Re);
G = zeros(length(d),2);
G(:,1) = 1;
G(:,2) = log(Ri0.*(1-hav./h0));
for i = 1 : length(d)
    %Cd(i,i) = (d(i)).^2;
    Cd(i,i) = 1;
end
m = Inv(G,d,Cd);
a = exp(m(1));
alpha = m(2);
alpha_best = alpha;
a_best = a;
ym = a.*(Ri0.*(1-hav./h0)).^(alpha);
yd = dhdt./Re;
Missfit_Ri = sqrt(mean((log(ym)-log(yd)).^2./(log(ym).^2)));


X = [1e-6:1e-5:10];
Erm = X;
subplot(1,2,1)
loglog(X,Erm,LineC_erosion,'LineWidth',Linewidth)
hold on


alpha = -1.5;
d = dhdt./Re;
G = zeros(length(d),1);
G(:,1) = (Ri0.*(1-hav./h0)).^(alpha);
for i = 1 : length(d)
    Cd(i,i) = (d(i));
    %Cd(i,i) = 1;
end
m = Inv(G,d,Cd);
a = m(1);
alpha_1 = alpha;
a_1 = a;


% With Reynolds and Rossby
d = log(dhdt./Re);
G = zeros(length(d),4);
G(:,1) = 1;
G(:,2) = log(Ri0.*(1-hav./h0));
G(:,3) = log(Re);
G(:,4) = log(Ro);
for i = 1 : length(d)
    %Cd(i,i) = (d(i)).^2;
    Cd(i,i) = 1;
end
m = Inv(G,d,Cd);
a = exp(m(1));
alpha_Ri = m(2);
alpha_Re = m(3);
alpha_Ro = m(4);


% With RaC and Ekman
RaC_mod = RaC.*Ek;
RaT_mod = RaT.*Ek.^2;

d = log(dhdt./Re./(Ri0.*(1-hav./h0)).^(-1.6));
G = zeros(length(d),3);
G(:,1) = 1;
%G(:,2) = log(Ri0.*(1-hav./h0));
G(:,2) = log(RaC_mod);
G(:,3) = log(Ek);
for i = 1 : length(d)
    %Cd(i,i) = (d(i)).^2;
    Cd(i,i) = 1;
end
m = Inv(G,d,Cd);
a_all = exp(m(1));
alpha_Ri2 = -1.6;
alpha_RaC = m(2);
alpha_Ek = m(3);
ym = a_all.*(Ri0.*(1-hav./h0)).^(-1.6).*RaC_mod.^alpha_RaC.*Ek.^alpha_Ek;
yd = dhdt./Re;
Missfit_RiEkRaC = sqrt(mean((log(ym)-log(yd)).^2./(log(ym).^2)));

%
% X = [1:1:1e6];
% Erm = a.*(X).^(alpha);
% loglog(X,Erm,LineC_erosion,'LineWidth',Linewidth)
% hold on

%--------------------
% PLOT DATA
%--------------------




%--------------------
% PLOT DATA
%--------------------

% Fit with all
subplot(1,2,1)

Ek_values = [3e-4, 1e-4, 3e-5, 1e-5];
MarkerEk = [MarkerE1, MarkerE2, MarkerE3, MarkerE4];
Nvalues = size(Ek_values);
Nvalues = Nvalues(2);

BestFit = 21.* (Ri0.*(1-hav./h0)).^(alpha_best).*RaC_mod.^(-0.19);

for i_Ek = 1:Nvalues
    %X = find((Ro<1e-2)&(Ro>5e-3))
    X = find(Ek==Ek_values(i_Ek))
    %X = find((Re<=100)&(Re>=50))
    %X = find((N_Omega_2>=1)&(N_Omega_2<=5))
    %X = find((Ro<1e-2)&(Ro>5e-3))
    
    er.Color = c_error;
    x_u = Ri0(X).*(1-hav(X)./h0(X)).*sqrt(alpha_best^2).*sqrt((Ri0_sd(X)./Ri0(X)).^2+(hsd(X)./hav(X)).^2);
    x_u = BestFit(X).*x_u./(Ri0(X).*(1-hav(X)./h0(X)));
    y_ul = dhdt(X)./Re(X).*sqrt((dhdt_ul(X)./dhdt(X)).^2+(Re_u(X)./Re(X)).^2); 
    y_ur = dhdt(X)./Re(X).*sqrt((dhdt_ur(X)./dhdt(X)).^2+(Re_u(X)./Re(X)).^2); 
    p_Ek0(i_Ek) = loglog(BestFit(X),dhdt(X)./Re(X),MarkerEk(i_Ek),...
        'MarkerSize',Markersize_loglog,...
        'MarkerEdgeColor',c_markeredge,...
        'MarkerFaceColor',c_RegimeErosion,'LineWidth',MarkerLinewidth)
    hold on
    er = errorbar(BestFit(X),dhdt(X)./Re(X),y_ul,y_ur,x_u,x_u,MarkerEk(i_Ek),...
        'CapSize',ErrorCap,...
        'MarkerSize',Markersize_loglog,...
        'MarkerEdgeColor',c_markeredge,...
        'MarkerFaceColor',c_RegimeErosion,'LineWidth',MarkerLinewidth);
end



for i_Ek = 1:Nvalues
    %X = find((Ro<1e-2)&(Ro>5e-3))
    X = find(Ek==Ek_values(i_Ek))
    %X = find((Re<=100)&(Re>=50))
    %X = find((N_Omega_2>=1)&(N_Omega_2<=5))
    %X = find((Ro<1e-2)&(Ro>5e-3))
    
    er.Color = c_error;
    p_Ek0(i_Ek) = loglog(BestFit(X),dhdt(X)./Re(X),MarkerEk(i_Ek),...
        'MarkerSize',Markersize_loglog,...
        'MarkerEdgeColor',c_markeredge,...
        'MarkerFaceColor',c_RegimeErosion,'LineWidth',MarkerLinewidth)
    hold on
end


xlabel('$c_2\,Ri^n\,Ra_\xi^{n_4}$','Interpreter',Inter,'FontSize',FontsizeX)
ylabel('Erosion rate, $E$','Interpreter',Inter,'FontSize',FontsizeY)
set(gca,'FontSize',FontsizeInFig)
txt1 = ['$y = (' num2str(a_best) ') x^{' num2str(alpha_best) '}$'];


l = legend([p_Ek0],'$E=3\times 10^{-4}$','$E=10^{-4}$','$E=3\times10^{-5}$','$E=10^{-5}$','Location','northwest')
set(l, 'interpreter', Inter,'FontSize',FontsizeInFig)
axis([3e-6 3 3e-6 3])
box on;
pbaspect([1 1 1]);
set(f,'PaperSize',[FigSize2(3) FigSize2(4)],'PaperUnits','points');
set(f,'Position',FigSize2);

txt1 = ['\textbf{a}'];
text(5e-6,8,txt1,'Interpreter','latex','FontSize',FontsizeInFig)


%==========================================
% Geophysical implications
%==========================================


cd ../../
SetFigureDefaults_2
cd ./FiguresSupplementary/ErosionFit/


%-------------------
% INPUT PARAMETERS
%-------------------

%Scaling for erosion rate 
% Dimensionless erosion rate = a Ri^(n)
a = 20;
n = -1.6 ;
n_4 = -0.19;

Omega = 7.2722e-05; %Current rotation rate (s^-1). 
R_o = 3.4e6;%outer core radius (meter).
R_i=0;%inner core radius (meter)
D = R_o-R_i;%Outer-core shell thickness
rho = 1.09e4;%Outer core density
Vs = 4/3*pi*((R_o)^3-(R_i)^3);%Shell volume
g = 10.68;%gravitational acceleration in the outer core
L = 3e5;%Layer thickness (meter) (matters only if plotting N/Omega)

%Varied parameters
Pconv = [0.003,0.01,0.03,0.1,0.3,1,3,10];
Pconv = Pconv*1e12;%Buoyancy flux available to the dynamo in W.

%Dimensionless power (see Landeau et al 2017)
p = Pconv./(Vs.*rho*Omega.^3.*D.^2);

logNrho = [-5.4:0.01:0.1]; 
Nrho = 10.^(logNrho);%Compositional density difference anomaly


%-----------------------------------------
% COMPUTE EROSION RATE VS DENSITY JUMP
% FOR GIVEN CONVECTIVE POWER
%-----------------------------------------

%Richardson number
for i =1:length(Nrho)
    for k =1:length(p)
        U_1(i,k) =  1.31.*p(k).^(0.42).*Omega.*D; % Scaling from Aubert et al 2009
        Ri_2(i,k)= Nrho(i).*g.*D./(U_1(i,k)).^2; % Richardson for a given erosion rate, deduced from scaling law 
        RaC(i,k)= Nrho(i).*g./(Omega.^2.*D); 
    end
end
%Erosion rate
E = a.*(-n+1).*(Ri_2).^(n).*RaC.^(n_4);
E = E.* U_1;


%-------------------
% PLOT
%-------------------
subplot(1,2,2)


Emax = E(3,end).*3600*24*365*1e9/1e3;
logEmax = round(log10(Emax));
Emax = 10^(logEmax);
Emin = E(end,2).*3600*24*365*1e9/1e3;   
logEmin = round(log10(Emin));
Emin = 10^(logEmin-1);

k = 1;
x(:,1) = Nrho(1,:)'*100;
y(1:length(Nrho),1) = E(:,k).*3600*24*365*1e9/1e3;
loglog(x,y,LineType_erosion,'LineWidth',Linewidth,'Color',LineC_erosion)
hold on 



%Positioning Core formation models (Landeau et al 2016, Jacobson et al 2017, Rubie et al. 2011)
Xc = [0.01,0.01,3,3];
junk = find(Nrho>=0.0001);
i1   = junk(1);
junk = find(Nrho>=0.03);
i2   = junk(1);

Yc1 = E(i1,7).*3600*24*365*1e9/1e3;
Yc2 = E(i1,2).*3600*24*365*1e9/1e3;
Yc3 = E(i2,2).*3600*24*365*1e9/1e3;
Yc4 = E(i2,7).*3600*24*365*1e9/1e3;
Yc = [Yc1, Yc2, Yc3, Yc4];
box1 = fill(Xc,Yc,c_CoreFormation,'edgecolor',...
    c_CoreFormation,'FaceAlpha', transparency,...
    'LineWidth',Linewidth_thick)

%Positioning upper bound for strat from seismology. Brodholt and Badro 2018
Xc = [1e-3,1e-3,1,1];
junk = find(Nrho>=0.00001);
i1   = junk(1);
junk = find(Nrho>=0.01);
i2   = junk(1);

Yc1 = E(i1,7).*3600*24*365*1e9/1e3;
Yc2 = E(i1,5).*3600*24*365*1e9/1e3;
Yc3 = E(i2,5).*3600*24*365*1e9/1e3;
Yc4 = E(i2,7).*3600*24*365*1e9/1e3;
Yc = [Yc1, Yc2, Yc3, Yc4];
fill(Xc,Yc,c_Seismo,'edgecolor','none',...
    'FaceAlpha', 0.6,...
    'LineWidth',Linewidth_thick)

%Positioning stratification seen by Geomag (Buffett et al 2016, Olson et al 2018)
Xc = [0.0038,0.0038,0.0634,0.0634];
junk = find(Nrho>=0.000038);
i1   = junk(1);
junk = find(Nrho>=0.000634);
i2   = junk(1);

Yc1 = E(i1,7).*3600*24*365*1e9/1e3;
Yc2 = E(i1,5).*3600*24*365*1e9/1e3;
Yc3 = E(i2,5).*3600*24*365*1e9/1e3;
Yc4 = E(i2,7).*3600*24*365*1e9/1e3;
Yc = [Yc1, Yc2, Yc3, Yc4];
box1 = fill(Xc,Yc,c_Geomag,'edgecolor',...
    BoxEdge,'FaceAlpha', 0.8,...
    'LineWidth',Linewidth_thick)



for k = length(p):-1:1
    x(:,1) = Nrho(1,:)'*100;
    y(1:length(Nrho),1) = E(:,k).*3600*24*365*1e9/1e3;
    loglog(x,y,LineType_erosion,'LineWidth',Linewidth,'Color',LineC_erosion)
    axis([10e-4 3e1 Emin Emax])
    hold on
    
    % Positioning of text on curves
    c2 = (logEmax-logEmin)/(4);
    c1 = Emax/((10)^(c2));
    Diag = c1 .* x.^(c2);
    Y = y - Diag;
    
    junk = find(x>=4.5);
    if ((isempty(junk)==0)&(k<9))
        j = junk(1);
        txt1 = [num2str(Pconv(k)/1e12) '\hspace{0.1cm}TW'];
        text(x(j), y(j), txt1, 'BackgroundColor', Background, 'rotation', -28,'Interpreter',Inter,'FontSize',FontsizeInFig_small);
        
    end
    clear x
    clear y
    
end



box on;

set(f,'Position',FigSize1);
pbaspect([1 1 1]);
xlabel('Density anomaly (\%)', 'interpreter', 'latex','FontSize',FontsizeX)
ylabel('Erosion rate (km/Ga)', 'interpreter', 'latex','FontSize',FontsizeY)
set(gca,'FontSize',FontsizeInAxes)
set(gca, 'Layer', 'top')
%!open Implications_3.pdf

txt1 = ['\textbf{b}'];
text(1.5e-3,2000,txt1,'Interpreter','latex','FontSize',FontsizeInFig)
box on;
pbaspect([1 1 1]);
set(f,'PaperSize',[FigSize2(3) FigSize2(4)],'PaperUnits','points');
set(f,'Position',FigSize2);


print(f,'Figure_BestFitRaC.pdf','-dpdf');

end
