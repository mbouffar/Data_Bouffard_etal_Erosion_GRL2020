function [] = plot_regime_diagram_Ek_RaX ()

close all

%--------------
% Commons
%--------------

cd ../
SetFigureDefaults_2
cd ./Figure2/

%--------------
% Enter DATA
%--------------

% All data are now in a big DATA array

DATA = define_data ();

Ra_crit_Ek15 = 5.18e-8;
Ra_crit_Ek35 = 3.34e-7;
Ra_crit_Ek14 = 2.61e-6;
Ra_crit_Ek34 = 1.72e-5;

DATA(:,9);
ndata = length(DATA(:,9))

for i = 1:ndata
   if (DATA(i,2) == 3e-4)
      Ra_crit(i) = Ra_crit_Ek34;
   elseif (DATA(i,2) == 1e-4)
      Ra_crit(i) = Ra_crit_Ek14;
   elseif (DATA(i,2) == 3e-5)
      Ra_crit(i) = Ra_crit_Ek35;
   elseif (DATA(i,2) == 1e-5)
      Ra_crit(i) = Ra_crit_Ek15;
   end
end

Ra_crit;

RaT_Omega = DATA(:,3).*DATA(:,2).^2;
RaC_Omega = DATA(:,4).*DATA(:,2);
Ri0 = (DATA(:,4)./(DATA(:,6).^2.*DATA(:,2)));

for i = 1:ndata
    RaT_Omega_superc(i) = RaT_Omega(i)/Ra_crit(i);
end

i_WLC = 0;
n_WLC = 0;

for i = 1:ndata
    if DATA(i,9) == 1       % WLC
        n_WLC = n_WLC + 1;
        %   elseif DATA(i,9) == 2  % E+DDC
        %n_GEdd = n_GEdd + 1;
        %elseif DATA(i,9) == 3                   % E
        %n_GE = n_GE + 1;
    end
end

n_WLC
%n_GEdd
%n_GE

RaT_WLC = zeros(1,n_WLC);
RaC_WLC = zeros(1,n_WLC);
N2_Omega2_WLC = zeros(1,n_WLC);
E_WLC = zeros(1,n_WLC);
Ri0_WLC = zeros(1,n_WLC);
RaT_Omega_WLC = zeros(1,n_WLC);

for i = 1:ndata
    if DATA(i,9) == 1       % WLC
        i_WLC = i_WLC + 1;
        RaT_WLC(i_WLC) = DATA(i,3);
        RaC_WLC(i_WLC) = DATA(i,4);
        N2_Omega2_WLC(i_WLC) = DATA(i,5);
        E_WLC(i_WLC) = DATA(i,2);
        Ri0_WLC(i_WLC) = Ri0(i);
        RaT_Omega_WLC(i_WLC) = RaT_Omega(i)/Ra_crit(i);
        RaC_Omega_WLC(i_WLC) = RaC_Omega(i);
    end
end

RaT_Omega_WLC
RaC_Omega_WLC
Ri0_WLC


%RaT_WLC = [3e3 1e4 3e4 3e3 1e5];
%RaC_WLC = [2e1 1e2 5e2 3e1 1e3];

%Ro_WLC  = [1.54e-2 3.16e-2 4.36e-2 5.8e-3 2.22e-2];
%dRo_WLC = [];
%N2_Omega2_WLC = [2.73e-2 1.37e-1 6.83e-1 1.37e-2 1.37e-1];
%E_WLC  = [3e-4 3e-4 3e-4 1e-4 3e-5];

%RaT_GE = [3e3 3e3 3e3 3e3 1e4 1e4 1e4 3e4 3e4 3e4 3e3 3e3 3e3 3e3 3e3 3e4];
%RaC_GE = [1e2 3e2 1e3 3e3 3e2 1e3 3e3 5e3 2e4 5e4 1e2 2e2 3e2 3e3 1e4 2e3];
%Ro_GE = [1.49e-2 1.23e-2 1e-2 9.3e-3 3.09e-2 2.73e-2 2.81e-2 3.63e-2 3.93e-2 3.76e-2 5.86e-3 4.94e-3 5.2e-3 3.4e-3 2.9e-3 2.22e-2];
%dRo_GE = [];
%N2_Omega2_GE = [1.37e-1 4.1e-1 1.37 4.1 4.1e-1 1.37 4.1 6.83 2.73e1 6.83e1 4.55e-2 9.1e-2 1.37e-1 1.37 4.55 9.1e-1];
%E_GE  = [3e-4 3e-4 3e-4 3e-4 3e-4 3e-4 3e-4 3e-4 3e-4 3e-4 1e-4 1e-4 1e-4 1e-4 1e-4 1e-4];

%RaT_GEdd = [2e4 5e4 1e5 5e4];
%RaC_GEdd = [5e2 2e3 5e3 1e3];
%Ro_GEdd = [5.2e-3 9.9e-3 1.84e-2 9.5e-3];
%N2_Omega2_GEdd = [6.83e-2 2.73e-1 6.83e-1 1.37e-1];
%E_GEdd = [3e-5 3e-5 3e-5 3e-5]
h0 = 0.2;

%BR_Earth_min = 1;
%BR_Earth_max = 100;
%Ro_Earth_min = 1e-6;
%Ro_Earth_max = 3e-6;


%--------------
% PLOT
%--------------


f1 = figure(1)
% Place simulations
%scatter(Ri0(1:13),RaT_Omega_superc(1:13),Markersize,RaC_Omega(1:13),'filled',...
%              MarkerE1,...
%              'MarkerEdgeColor',c_markeredge,...
%              'LineWidth',MarkerLinewidth);
hold on;
%scatter(Ri0(14:20),RaT_Omega_superc(14:20),Markersize,RaC_Omega(14:20),'filled',...
%              MarkerE2,...
%              'MarkerEdgeColor',c_markeredge,...
%              'LineWidth',MarkerLinewidth);
%scatter(Ri0(21:28),RaT_Omega_superc(21:28),Markersize,RaC_Omega(21:28),'filled',...
%              MarkerE3,...
%              'MarkerEdgeColor',c_markeredge,...
%              'LineWidth',MarkerLinewidth);
%scatter(Ri0(29:30),RaT_Omega_superc(29:30),Markersize,RaC_Omega(29:30),'filled',...
%              MarkerE4,...
%              'MarkerEdgeColor',c_markeredge,...
%              'LineWidth',MarkerLinewidth);

% ERROR BARS AS WELL??

% Add the Earth
%width = Ro_Earth_max-Ro_Earth_min; % whatever
%height = BR_Earth_max-BR_Earth_min; % whatever...
%xCenter = (Ro_Earth_min+Ro_Earth_max)*0.5; % Wherever...
%yCenter = (BR_Earth_min+BR_Earth_max)*0.5; % Wherever...
%xLeft = xCenter - width/2;
%yBottom = yCenter - height/2;
%rectangle('Position', [xLeft, yBottom, width, height], 'EdgeColor', 'k', 'FaceColor', 'm', 'LineWidth', 3);

grid on;


% Set grid
x_min = 10;
x_max = 2e5;
y_min = 7;
y_max = 400;

xlim([x_min x_max])
ylim([y_min y_max])

set(gca,'xscale','log','yscale','log')

ylabel('Strength of convection, $Ra_T/Ra_{T,c}$', 'interpreter', Inter,'FontSize',FontsizeX)
xlabel('Richardson number, $Ri_0$','interpreter',Inter,'FontSize',FontsizeY)
set(gca,'FontSize',FontsizeInAxes)

% Add line separating regimes, below symbols
%y = linspace(y_min,y_max,1000);
%x = 93*ones(1000);
%plot(x,y,LineType_regime,'LineWidth',Linewidth_regime,'Color',LineC_erosion)
%b = 0.058./h0;
%y = b*x.^a;
%plot(x,y,LineType_regime,'LineWidth',Linewidth_regime,'Color',LineC_erosion)

% Place simulations on top
scatter(Ri0(1:15),RaT_Omega_superc(1:15),Markersize,RaC_Omega(1:15),'filled',...
              MarkerE1,...
              'MarkerEdgeColor',c_markeredge,...
              'LineWidth',MarkerLinewidth);
scatter(Ri0(16:22),RaT_Omega_superc(16:22),Markersize,RaC_Omega(16:22),'filled',...
              MarkerE2,...
              'MarkerEdgeColor',c_markeredge,...
              'LineWidth',MarkerLinewidth);
scatter(Ri0(23:30),RaT_Omega_superc(23:30),Markersize,RaC_Omega(23:30),'filled',...
              MarkerE3,...
              'MarkerEdgeColor',c_markeredge,...
              'LineWidth',MarkerLinewidth);
scatter(Ri0(31:32),RaT_Omega_superc(31:32),Markersize,RaC_Omega(31:32),'filled',...
              MarkerE4,...
              'MarkerEdgeColor',c_markeredge,...
              'LineWidth',MarkerLinewidth);

scatter(Ri0_WLC(4),RaT_Omega_WLC(4),Markersize,RaC_Omega_WLC(4),'filled',...
              MarkerE2,...
              'MarkerEdgeColor',c_markeredge,...
              'LineWidth',MarkerLinewidth*3);
scatter(Ri0_WLC(5),RaT_Omega_WLC(5),Markersize,RaC_Omega_WLC(5),'filled',...
              MarkerE3,...
              'MarkerEdgeColor',c_markeredge,...
              'LineWidth',MarkerLinewidth*3);
scatter(Ri0_WLC(1),RaT_Omega_WLC(1),Markersize,RaC_Omega_WLC(1),'filled',...
              MarkerE1,...
              'MarkerEdgeColor',c_markeredge,...
              'LineWidth',MarkerLinewidth*3);
scatter(Ri0_WLC(2),RaT_Omega_WLC(2),Markersize,RaC_Omega_WLC(2),'filled',...
              MarkerE1,...
              'MarkerEdgeColor',c_markeredge,...
              'LineWidth',MarkerLinewidth*3);
scatter(Ri0_WLC(3),RaT_Omega_WLC(3),Markersize,RaC_Omega_WLC(3),'filled',...
              MarkerE1,...
              'MarkerEdgeColor',c_markeredge,...
              'LineWidth',MarkerLinewidth*3);
pbaspect([1 1 1]);
box on;
l = legend({'$Ek = 3 \times 10^{-4}$','$Ek = 10^{-4}$','$Ek = 3 \times 10^{-5}$','$Ek = 10^{-5}$'},'Interpreter','latex','Location','east','FontSize',FontsizeInAxes)
%set(l, 'interpreter',
%Inter,'FontSize',FontsizeInFig,'Location','east')
h = colorbar;
set(get(h,'title'),'string','$Ra_\xi$','interpreter','latex','FontSize',FontsizeY);
set(gca,'colorscale','log');
set(f1,'Position',FigSize1);
print('-dpdf','Figure1_EkRaX.pdf')


end
