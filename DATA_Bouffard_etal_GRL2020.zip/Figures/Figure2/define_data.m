function [DATA] = define_data ()% Store all simulations time average data in one big table
% Columns are:
% [Run_id Ek RaT RaC (N_xi/Omega)^2 U_rms U^conv_rms U^nz_rms Regime]
% Regime = 1 for WLC, 2 for GE+DDC, 3 for GE
% For WLC, U^conv_rms is replaced by U_rms

%       Id   Ek   RaT  RaC  N/Omega  Utot    Uconv   Upol   R  h
DATA = [ 1  3e-4  3e3  2e1  2.73e-2  51.13   51.13   27.56  1  0.2
         2  3e-4  3e3  1e2  1.37e-1  49.76   45.38   26.86  3  0.2
         3  3e-4  3e3  3e2  4.10e-1  40.86   45.37   19.59  3  0.2
         4  3e-4  3e3  1e3   1.37    34.07   41.98   12.93  3  0.2
         5  3e-4  3e3  3e3   4.10    31.15   39.69   10.89  3  0.2
         6  3e-4  1e4  1e2  1.37e-1  105.49  105.49  78.27  1  0.2
         7  3e-4  1e4  3e2  4.10e-1  102.65  91.06   57.94  3  0.2
         8  3e-4  1e4  1e3   1.37    91.21   96.48   46.92  3  0.2
         9  3e-4  1e4  3e3   4.10    95.69   115.19  37.58  3  0.2
        10  3e-4  3e4  5e2  6.83e-1  145.35  156.52  72.10  1  0.2
        11  3e-4  3e4  5e3   6.83    151.67  184.67  75.70  3  0.2
        12  3e-4  3e4  2e4  2.73e1   158.17  197.37  69.12  3  0.2
        13  3e-4  3e4  5e4  6.83e1   153.07  193.82  68.40  3  0.2
        14  3e-4  6e3  3e2  4.61e-1  76.27   63.45   34.22  3  0.1
        15  3e-4  6e3  3e2  4.46e-2  67.87   37.51   29.81  3  0.3
        16  1e-4  3e3  3e1  1.37e-2  57.98   51.52   29.08  1  0.2
        17  1e-4  3e3  1e2  4.55e-2  55.29   53.12   27.04  3  0.2
        18  1e-4  3e3  2e2  9.10e-2  50.06   54.80   22.93  3  0.2
        19  1e-4  3e3  3e2  1.37e-1  48.04   54.54   21.31  3  0.2
        20  1e-4  3e3  3e3   1.37    36.16   45.86   11.56  3  0.2
        21  1e-4  3e3  1e4   4.55    32.08   41.38   10.28  3  0.2
%        20  1e-4  3e3  3e4  1.37e1   196.98  108.20  188.93 3 
        22  1e-4  3e4  2e3  9.10e-1  220.90  243.15  108.27 3  0.2
        23  3e-5  1e4  2e2  2.73e-2  143.76  135.80  74.90  2  0.2
%        22  3e-5  1e4  1e6  1.37e2   1486.6  567.42  1447.2 3
        24  3e-5  2e4  5e2  6.83e-2  219.00  212.66  116.14 2  0.2
        25  3e-5  5e4  1e3  1.37e-1  351.41  381.94  162.89 2  0.2
        26  3e-5  5e4  2e3  2.73e-1  281.50  337.28  89.28  2  0.2
        27  3e-5  5e4  5e3  6.83e-1  280.33  346.77  78.69  3  0.2
        28  3e-5  1e5  1e3  1.37e-1  739.13  850.91  262.70 1  0.2
        29  3e-5  1e5  5e3  6.83e-1  611.52  734.50  198.87 2  0.2
        30  3e-5  1e5  1e4   1.37    579.67  861.41  161.59 3  0.2
        31  1e-5  1e4  2e2  9.10e-3  185.53  180.67  88.45  2  0.2
        32  1e-5  3e4  8e2  3.64e-2  309.61  336.45  126.54 2  0.2];
%        32  1e-5  3e4  8e2  
%        33  1e-5  3e5  3e6  1.37e1 
%                                                              ];

RaT_Omega = DATA(:,3).*DATA(:,2).^2;
RaC_Omega = DATA(:,4).*DATA(:,2);
Ri0 = (DATA(:,4)./(DATA(:,6).^2.*DATA(:,2)));

RaT_Omega(14:15);
RaC_Omega(14:15);
Ri0(14:15);

Ra_crit_Ek15 = 5.18e-8;
Ra_crit_Ek35 = 3.34e-7;
Ra_crit_Ek14 = 2.61e-6;
Ra_crit_Ek34 = 1.72e-5; 

for i = 1:length(DATA(:,1))
   if (DATA(i,2) == 3e-4)
      Criticality(i) = RaT_Omega(i)/Ra_crit_Ek34;
   elseif (DATA(i,2) == 1e-4)
      Criticality(i) = RaT_Omega(i)/Ra_crit_Ek14;
   elseif (DATA(i,2) == 3e-5)
      Criticality(i) = RaT_Omega(i)/Ra_crit_Ek35;
   elseif (DATA(i,2) == 1e-5)
      Criticality(i) = RaT_Omega(i)/Ra_crit_Ek15;
   end	
end

min(Criticality)
max(Criticality)


end
