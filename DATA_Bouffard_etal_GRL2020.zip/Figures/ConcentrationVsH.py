import numpy as np   
import matplotlib.pyplot as plt



#Input parameters
ri = 1./0.9-1.
ro = 1./0.9
h0 = 0.2
h = np.arange(0.,0.2,1e-3)



F = (1./4.*(ro-h)**4.-1./4.*(ro-h0)**4.+(h0-ro)*1./3.*((ro-h)**3.-(ro-h0)**3.))
F = 1./(1./3.*h0*((ro-h)**3.-ri**3.))*F

plt.figure()
plt.plot(h,F,'r')
plt.show()