% Figure size
FigSize1 = [360 278 450 450];
FigSize2 = [0 0 900 450];
FigSize3 = [0 0 1000 900];
FigSize4 = [0 0 1000 900];

% Line specs
Linewidth = 0.75; 
Linewidth_thick = 2;
LineType_erosion ='-';  
LineType_regime  ='--';
Linewidth_regime = 0.8;
LineType_slope   = ':';
% Text in figure
Background = 'w';
Inter = 'latex';

% Colours
% https://www.mathworks.com/help/matlab/ref/rectangle.html
c_RegimeErosion    = [1, 0.6, 0.2];
c_RegimeWholeLayer = [0 0.4470 0.7410];
c_CoreFormation = [0.9290 0.6940 0.1250];
c_markeredge = 'k';
c_Geomag = [0 0.4470 0.7410];
c_Seismo = [0.4660 0.6740 0.1880];
c_error = [0, 0, 0];
BoxEdge = 'none';
LineC_erosion = 'k';
%LineC_regime = 'k';
LineC_regime = c_RegimeWholeLayer;
transparency = 1;

%Marker
Markersize = 100;
Markersize_loglog = 10;
MarkerWLC = 'diamond';
MarkerGEdd = 's';
MarkerGE = 'o';
MarkerLinewidth = 1;
MarkerE1 = 'o';
MarkerE2 = 's';
MarkerE3 = 'd';
MarkerE4 = 'v';
ErrorCap = 0;


% Font: size, etc
FontsizeInFig = 16;
FontsizeInFig_small = 14;
FontsizeInFig_smallsmall = 13;
FontsizeInFig_extrasmall = 12;
FontsizeX = 16;
FontsizeY = 16;
FontsizeInAxes = 16 ;

