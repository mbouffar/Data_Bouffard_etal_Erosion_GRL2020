import numpy as np
from scipy import linalg
def Inv_leastsquares(G,d,Cd):
    #Function that estimate the best least square model m 
    #with data d such that d = Gm 
    #Cd : covariance matrix. The diagonal contains the data uncertainties squared 
    Cdi = linalg.inv(Cd)
    A   = np.dot(np.dot(np.transpose(G),Cdi),G)
    A   = linalg.inv(A)
    B   = np.dot(Cdi,d)
    B   = np.dot(np.transpose(G),B)
    m   = np.dot(A,B);
    return m



#Cdi = inv(Cd);
#A = inv(G'*Cdi*G);
#B  = A * G' * Cdi;
#m = B * d;