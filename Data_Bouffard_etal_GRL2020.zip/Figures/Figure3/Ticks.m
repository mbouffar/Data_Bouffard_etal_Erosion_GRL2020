function [Ticks,TickLabels] = TicksChg(A,num_of_ticks)
% get the minimum and maximum value of A
c1 = min(min(A));
c2 = max(max(A));
% set limits for the caxis
caxis([log10(c1) log10(c2)]);
% preallocate Ticks and TickLabels
Ticks      = zeros(1,num_of_ticks);
TickLabels = zeros(1,num_of_ticks);
% distribute Ticks and TickLabels
for n = 1:1:num_of_ticks
    
    Ticks(n)      = log10(round(c2)/num_of_ticks*n);
    TickLabels(n) = round(c2)/num_of_ticks*n;
end
% set Ticks and TickLabels
%colorbar('Ticks',Ticks,'TickLabels',TickLabels)