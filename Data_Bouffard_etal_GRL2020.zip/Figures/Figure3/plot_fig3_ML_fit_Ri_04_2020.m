function [] = plot_fig3_ML_fit_4 ()

  %==========================================
    % Commons
    %==========================================
    
    cd ../
    SetFigureDefaults_2
    cd ./Figure3/
    
    
    f = figure(1)
    
    %==========================================
    %     Subplot 1 : h(t)
    %==========================================
    subplot(1,2,1)
    
    % INPUTS
    Re = 65;
    t_slope = 0.2; %Time to depict slope
    t_slope = t_slope * Re;
    Dt_slope = 0.03 * Re;%Dt to depict slope at t_slope +/- Dt_slope
    i0 = 8; % Time index to start the fit. 
    
    % LOAD DATA
    name = '../Data/data_Ek_3e_4_RaT_1e4_RaC_1e3.mat'
    h0 = 0.2;
    Ek = 3e-4;
    RaT = 1e4;
    RaC = 1e3;
    
    Data = importdata(name);
    T = Data(1:end,1);
    h = Data(1:end,2);
    U = sqrt(Data(1:end,end));
    
    
    %INITIAL CONDITIONS
    t1 = T(i0);
    h1 = h(i0);
    T  = T - t1;
    T = T*Re;
    
    figure(1)
    subplot(1,2,1)
    
    % BEST FIT
    [hm,a_best,beta_best]=Thickness_BestFit(h,i0,h0,h1,T) % Best fit, rough estiation for now 
    plot(T,hm.*h0,LineType_erosion,'LineWidth',Linewidth,'Color',LineC_erosion)
    hold on 
    plot(T(i0:end),h(i0:end),LineType_erosion,'LineWidth',Linewidth_thick,'Color',c_RegimeErosion)
    
    % FIND SLOPE AND TANGENT EQUATION
    X = find(T>=t_slope);
    k = X(1);
    dhdt = gradient(hm.*h0,T);
    DhDt = dhdt(k);
    b = hm(k).*h0-DhDt * t_slope; 
    y = DhDt.*T + b;
    %plot(T,y,LineType_slope,'LineWidth',Linewidth,'Color',LineC_erosion)
    
    % Vertical bar to represent slope
    x1 = t_slope-Dt_slope;
    x2 = t_slope+Dt_slope;
    y1 = DhDt.*x1+ b;
    y2 = DhDt.*x2 + b;
    x = [x1, x1];
    y = [y1, y2];
    plot(x,y,LineType_erosion,'LineWidth',Linewidth,'Color',LineC_erosion)
    
    % Horizontal bar to represent slope
    x = [x1, x2];
    y = [y2, y2];
    plot(x,y,LineType_erosion,'LineWidth',Linewidth,'Color',LineC_erosion)
    
    % DECO
    box on;
    pbaspect([1 1 1]);
    xlabel('Time (in advective time units)','Interpreter',Inter,'FontSize',FontsizeX)
    ylabel('Layer thickness, $h$','Interpreter',Inter,'FontSize',FontsizeY)
    set(gca,'FontSize',FontsizeInFig)
    
    txt1 = ['\textbf{a}'];
    text(0,0.215,txt1,'Interpreter',Inter,'FontSize',FontsizeInFig)
    txt1 = ['$-E$'];
    text(0.18*Re,0.088,txt1,'Interpreter',Inter,'FontSize',FontsizeInFig)
    
    axis([0 0.34*Re 0.05 0.2])
    
    %==========================================
    % Subplot 2 : Scaling law
    %==========================================
    % INPUT
    m = 1 ; % Choose data sets to consider. If m = 1 : first measurement for each simulation only, 
    %if m = 2 second measurement only, if m=3 two measurements per simulation
    
    subplot(1,2,2)
    %--------------------
    % READ DATA
    %--------------------
    Erosion = xlsread('../Data/ErosionRate_local_fit_4.xlsx')
    Ek = Erosion(:,1);
    RaT = Erosion(:,2);
    RaC = Erosion(:,3);
    h0 = Erosion(:,4);
    n = 2; % n=1 Ri0 in convective region, n=2 Ri0 in full shell, n=3 Ri0 based on poloidal energy
    if n == 1
        Re   = Erosion(:,11);
        Re_u = Erosion(:,12);
        Ri0   = (RaC)./((Re).^2)./Ek;
        Ri0_sd = Erosion(:,6);
    elseif n==2
        Re   = Erosion(:,13);
        Re_u = Erosion(:,14);
        Ri0   = (RaC)./((Re).^2)./Ek;
        Ri0_sd = Erosion(:,8);
    elseif n==3
        Re   = Erosion(:,15);
        Re_u = Erosion(:,16);
        Ri0   = (RaC)./((Re).^2)./Ek;
        Ri0_sd = Erosion(:,10);
    end
    
    hsd = Erosion(:,18);
    h1 = Erosion(:,17);
    dhdt_1   = -Erosion(:,19);
    dhdt_1_beta_min   =- Erosion(:,20);
    dhdt_1_beta_max   =- Erosion(:,21);
    dhdt_1_CI_min   = -Erosion(:,22);
    dhdt_1_CI_max   = -Erosion(:,23);
    dhdt_1_ul = (dhdt_1 - min(dhdt_1_CI_max,dhdt_1_beta_max))/2;
    dhdt_1_ur =(-dhdt_1 + max(dhdt_1_CI_min,dhdt_1_beta_min))/2;
    
    
    h2 = Erosion(:,24);
    dhdt_2   = -Erosion(:,26);
    dhdt_2_beta_min   = -Erosion(:,27);
    dhdt_2_beta_max   = -Erosion(:,28);
    dhdt_2_CI_min   = -Erosion(:,29);
    dhdt_2_CI_max   = -Erosion(:,30);
    dhdt_2_ul = (dhdt_2 - min(dhdt_2_CI_max,dhdt_2_beta_max))/2;
    dhdt_2_ur =(-dhdt_2 + max(dhdt_2_CI_min,dhdt_2_beta_min))/2;
    
    
    N_Omega_2 = RaC.*Ek./h0;
    Ro = Ek.*Re;
    
    
    if m == 1 % One measurement per simulation, first one
    
        dhdt = dhdt_1;
        hav = h1;
        dhdt_beta_min = dhdt_1_beta_min;
        dhdt_beta_max = dhdt_1_beta_max;
        dhdt_CI_min = dhdt_1_CI_min;
        dhdt_CI_max = dhdt_1_CI_max;
        dhdt_ul = dhdt_1_ul;
        dhdt_ur = dhdt_1_ur;
        
    elseif m == 2  % One measurement per simulation, second one
        dhdt = dhdt_2;
        hav = h2;
        dhdt_beta_min = dhdt_2_beta_min;
        dhdt_beta_max = dhdt_2_beta_max;
        dhdt_CI_min = dhdt_2_CI_min;
        dhdt_CI_max = dhdt_2_CI_max;
        dhdt_ul = dhdt_2_ul;
        dhdt_ur = dhdt_2_ur;
    elseif m == 3    %Two measurements per simulation
        Ek = [Ek;Ek];
        RaC = [RaC;RaC];
        RaT = [RaT;RaT];
        hav = [h1;h2]
        dhdt = [dhdt_1;dhdt_2];
        dhdt_beta_min = [dhdt_1_beta_min;dhdt_2_beta_min];
        dhdt_beta_max = [dhdt_1_beta_max;dhdt_2_beta_max];
        dhdt_CI_min = [dhdt_1_CI_min;dhdt_2_CI_min];
        dhdt_CI_max = [dhdt_1_CI_max;dhdt_2_CI_max];
        dhdt_ul = [dhdt_1_ul;dhdt_2_ul];
        dhdt_ur = [dhdt_1_ur;dhdt_2_ur];
        
        Re   = [Re;Re];
        Re_u=[Re_u;Re_u];
        Ri0   = [Ri0;Ri0];
        Ri0_sd  = [Ri0_sd;Ri0_sd];
        h0 = [h0;h0];
        hsd = [hsd;hsd];
        N_Omega_2 = [N_Omega_2;N_Omega_2];
        Ro = [Ro;Ro];
    end
    
    %--------------------
    % BEST FIT
    %--------------------
    
    
    d = log(dhdt./Re);
    G = zeros(length(d),2);
    G(:,1) = 1.;
    G(:,2) = log(Ri0.*(1-hav./h0));
    Cd = zeros(length(d),length(d));
    for i = 1 : length(d)
        %Cd(i,i) = (d(i)).^2;
        Cd(i,i) = 1.;
    end
    m = Inv(G,d,Cd);
    a = exp(m(1));
    alpha = m(2);
    alpha_best = alpha
    a_best = a
    
    %a = 28.; % Best fit before adding h0 = 0.1, h0=0.3
    %alpha = -1.64;% Best fit before adding h0 = 0.1, h0=0.3
    
    X = [1:1:1e6];
    Erm = a.*(X).^(alpha);
    loglog(X,Erm,LineC_erosion,'LineWidth',Linewidth)
    hold on
    
    alpha = -1.4;
    d = dhdt./Re;
    G = zeros(length(d),1);
    G(:,1) = (Ri0.*(1-hav./h0)).^(alpha);
    for i = 1 : length(d)
        %Cd(i,i) = (d(i));
        Cd(i,i) = 1;
    end
    m = Inv(G,d,Cd);
    a = m(1);
    alpha_1 = alpha;
    a_1 = a;
    %
    % X = [1:1:1e6];
    % Erm = a.*(X).^(alpha);
    % loglog(X,Erm,LineC_erosion,'LineWidth',Linewidth)
    % hold on
    
    %--------------------
    % PLOT DATA
    %--------------------
    
    
    Ek_values = [3e-4, 1e-4, 3e-5, 1e-5];
    MarkerEk = [MarkerE1, MarkerE2, MarkerE3, MarkerE4];
    Nvalues = size(Ek_values);
    Nvalues = Nvalues(2);
    
    for i_Ek = 1:Nvalues
        X = find(Ek==Ek_values(i_Ek))
        er.Color = c_error;
        x_u = Ri0(X).*(1-hav(X)./h0(X)).*sqrt((Ri0_sd(X)./Ri0(X)).^2+(hsd(X)./hav(X)).^2);
        y_ul = dhdt(X)./Re(X).*sqrt((dhdt_ul(X)./dhdt(X)).^2+(Re_u(X)./Re(X)).^2);
        y_ur = dhdt(X)./Re(X).*sqrt((dhdt_ur(X)./dhdt(X)).^2+(Re_u(X)./Re(X)).^2);
        er = errorbar(Ri0(X).*(1-hav(X)./h0(X)),dhdt(X)./Re(X),y_ul,y_ur,x_u,x_u,MarkerEk(i_Ek),...
            'CapSize',ErrorCap,...
            'MarkerSize',Markersize_loglog,...
            'MarkerEdgeColor',c_markeredge,...
            'MarkerFaceColor',c_RegimeErosion,'LineWidth',MarkerLinewidth);
        p_Ek0(i_Ek) = loglog(Ri0(X).*(1-hav(X)./h0(X)),dhdt(X)./Re(X),MarkerEk(i_Ek),...
            'MarkerSize',Markersize_loglog,...
            'MarkerEdgeColor',c_markeredge,...
            'MarkerFaceColor',c_RegimeErosion,'LineWidth',MarkerLinewidth)
        hold on
        
    end
    
    
    xlabel('Richardson number, $Ri$','Interpreter',Inter,'FontSize',FontsizeX)
    ylabel('Erosion rate, $E$','Interpreter',Inter,'FontSize',FontsizeY)
    set(gca,'FontSize',FontsizeInFig)
    txt1 = ['$y = (' num2str(a_best) ') x^{' num2str(alpha_best) '}$'];
    %text(3e1,0.2,txt1,'Interpreter','latex','FontSize',15)
    
    
    l = legend([p_Ek0],'$E=3\times 10^{-4}$','$E=10^{-4}$','$E=3\times10^{-5}$','$E=10^{-5}$')
    set(l, 'interpreter', Inter,'FontSize',FontsizeInFig)
    
    
    axis([10 1e4 1e-5 1])
    box on;
    pbaspect([1 1 1]);
    txt1 = ['\textbf{b}'];
    text(10,3,txt1,'Interpreter','latex','FontSize',FontsizeInFig)
    set(f,'PaperSize',[FigSize2(3) FigSize2(4)],'PaperUnits','points');
    set(f,'Position',FigSize2);
    a_1
    alpha_1
    a_best
    alpha_best
    print(f,'Figure3.pdf','-dpdf');
    %close all;

end
