function [hm,a_best,beta_best]=Thickness_BestFit(h,i0,h0,h1,T)

% BEST FIT
% Data
d = (1-h(i0:end)./h0)./(1-h1./h0);
% Model
a = [0.1:0.1:100];
beta = [1/3:0.01:0.67];
%beta = 0.4;
for i = 1 : length(a)
    for j = 1 : length(beta)
        ym = (1+a(i).*T(i0:end)).^(beta(j));
        Cd = 1;
        %Cd = d.^2;
        E(i,j)  = mean((d-ym).^2./Cd);
    end
end

[x,y] = find(E==min(min(E)))
a_best = a(x);
beta_best = beta(y);

% figure
% imagesc(beta,a,E)
% colorbar
% xlabel('beta')
% ylabel('a')
% caxis([0 1])
% hold on
% plot(beta_best,a_best,'or')

ym = (1+a_best.*T).^(beta_best);
hm = 1-ym.*(1-h1/h0);




