function [Ticks,TickLabels] = TicksChg(A,num_of_ticks)
% get the minimum and maximum value of A
c1 = min(A);
c2 = max(A);
c1log = round(log10(c1));
c2log = round(log10(c2));
% set limits for the caxis
caxis([log10(c1) log10(c2)]);
% preallocate Ticks and TickLabels
Ticks      = zeros(1,num_of_ticks);
TickLabels = zeros(1,num_of_ticks);
% distribute Ticks and TickLabels
for n = 1:1:num_of_ticks
    Ticks(n)      = c1log + (n-1) / num_of_ticks * (c2log-c1log);
    Ticks(n)      = 10.^(Ticks(n));
    TickLabels(n) = Ticks(n);
    %Ticks(n)      = log10(c1+ (n-1)/num_of_ticks*c2);
    %TickLabels(n) = c1+ c2/num_of_ticks*(n-1);
end
% set Ticks and TickLabels
%colorbar('Ticks',Ticks,'TickLabels',TickLabels)

%cbh = colorbar('peer', AxesH, 'h', ...
%               'XTickLabel',{'-12','-9','-6','-3','0','3','6','9','12'}, ...
%               'XTick', -12:3:12)