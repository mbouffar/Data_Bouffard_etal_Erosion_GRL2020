function [Synt] = MonteCarloUncertainties(X,X_u)
s = size(X);
Synt = (X-X_u) + rand(s).*2.*X_u;