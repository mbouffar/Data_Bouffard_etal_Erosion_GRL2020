clear all
close all

cd ../
SetFigureDefaults_2
cd ./Figure4/ 
%-------------------
% INPUT PARAMETERS
%-------------------

%Scaling for erosion rate 
% Dimensionless erosion rate = a Ri^(n)
a = 17;
n = -1.4 ;

Omega = 7.2722e-05; %Current rotation rate (s^-1). 
R_o = 3.4e6;%outer core radius (meter).
R_i=0;%inner core radius (meter)
D = R_o-R_i;%Outer-core shell thickness
rho = 1.09e4;%Outer core density
Vs = 4/3*pi*((R_o)^3-(R_i)^3);%Shell volume
g = 10.68;%gravitational acceleration in the outer core
L = 3e5;%Layer thickness (meter) (matters only if plotting N/Omega)

%Varied parameters
Pconv = [0.003,0.01,0.03,0.1,0.3,1,3,10];
Pconv = Pconv*1e12;%Buoyancy flux available to the dynamo in W.

%Dimensionless power (see Landeau et al 2017)
p = Pconv./(Vs.*rho*Omega.^3.*D.^2);

logNrho = [-5.4:0.01:0.1]; 
Nrho = 10.^(logNrho);%Compositional density difference anomaly


%-----------------------------------------
% COMPUTE EROSION RATE VS DENSITY JUMP
% FOR GIVEN CONVECTIVE POWER
%-----------------------------------------

%Richardson number
for i =1:length(Nrho)
    for k =1:length(p)
        U_1(i,k) =  1.31.*p(k).^(0.42).*Omega.*D; % Scaling from Aubert et al 2009
        Ri_2(i,k)= Nrho(i).*g.*D./(U_1(i,k)).^2; % Richardson for a given erosion rate, deduced from scaling law 
    end
end
%Erosion rate
E = a.*(-n+1).*(Ri_2).^(n);
E = E.* U_1;


%-------------------
% PLOT
%-------------------

f = figure 


Emax = E(3,end).*3600*24*365*1e9/1e3;
logEmax = round(log10(Emax));
Emax = 10^(logEmax);
Emin = E(end,2).*3600*24*365*1e9/1e3;   
logEmin = round(log10(Emin));
Emin = 10^(logEmin-1);

k = 1;
x(:,1) = Nrho(1,:)'*100;
y(1:length(Nrho),1) = E(:,k).*3600*24*365*1e9/1e3;
loglog(x,y,LineType_erosion,'LineWidth',Linewidth,'Color',LineC_erosion)
hold on 



%Positioning Core formation models (Landeau et al 2016, Jacobson et al 2017, Rubie et al. 2011)
Xc = [0.01,0.01,3,3];
junk = find(Nrho>=0.0001);
i1   = junk(1);
junk = find(Nrho>=0.03);
i2   = junk(1);

Yc1 = E(i1,7).*3600*24*365*1e9/1e3;
Yc2 = E(i1,2).*3600*24*365*1e9/1e3;
Yc3 = E(i2,2).*3600*24*365*1e9/1e3;
Yc4 = E(i2,7).*3600*24*365*1e9/1e3;
Yc = [Yc1, Yc2, Yc3, Yc4];
box1 = fill(Xc,Yc,c_CoreFormation,'edgecolor',...
    c_CoreFormation,'FaceAlpha', transparency,...
    'LineWidth',Linewidth_thick)

%Positioning upper bound for strat from seismology. Brodholt and Badro 2018
Xc = [1e-3,1e-3,1,1];
junk = find(Nrho>=0.00001);
i1   = junk(1);
junk = find(Nrho>=0.01);
i2   = junk(1);

Yc1 = E(i1,7).*3600*24*365*1e9/1e3;
Yc2 = E(i1,5).*3600*24*365*1e9/1e3;
Yc3 = E(i2,5).*3600*24*365*1e9/1e3;
Yc4 = E(i2,7).*3600*24*365*1e9/1e3;
Yc = [Yc1, Yc2, Yc3, Yc4];
fill(Xc,Yc,c_Seismo,'edgecolor','none',...
    'FaceAlpha', 0.6,...
    'LineWidth',Linewidth_thick)

%Positioning stratification seen by Geomag (Buffett et al 2016, Olson et al 2018)
Xc = [0.0038,0.0038,0.0634,0.0634];
junk = find(Nrho>=0.000038);
i1   = junk(1);
junk = find(Nrho>=0.000634);
i2   = junk(1);

Yc1 = E(i1,7).*3600*24*365*1e9/1e3;
Yc2 = E(i1,5).*3600*24*365*1e9/1e3;
Yc3 = E(i2,5).*3600*24*365*1e9/1e3;
Yc4 = E(i2,7).*3600*24*365*1e9/1e3;
Yc = [Yc1, Yc2, Yc3, Yc4];
box1 = fill(Xc,Yc,c_Geomag,'edgecolor',...
    BoxEdge,'FaceAlpha', 0.8,...
    'LineWidth',Linewidth_thick)



for k = 1:length(p)
    x(:,1) = Nrho(1,:)'*100;
    y(1:length(Nrho),1) = E(:,k).*3600*24*365*1e9/1e3;
    loglog(x,y,LineType_erosion,'LineWidth',Linewidth,'Color',LineC_erosion)
    axis([10e-4 3e1 Emin Emax])
    hold on
    
    % Positioning of text on curves
    c2 = (logEmax-logEmin)/(4);
    c1 = Emax/((10)^(c2));
    Diag = c1 .* x.^(c2);
    Y = y - Diag;
    
    junk = find(x>=4.5);
    if ((isempty(junk)==0)&(k<9))
        j = junk(1);
        txt1 = [num2str(Pconv(k)/1e12) '\hspace{0.1cm}TW'];
        text(x(j), y(j), txt1, 'BackgroundColor', Background, 'rotation', -26,'Interpreter',Inter,'FontSize',FontsizeInFig_smallsmall);
        
    end
    clear x
    clear y
    
end



box on;

set(f,'Position',FigSize1);
pbaspect([1 1 1]);
xlabel('Density anomaly (\%)', 'interpreter', 'latex','FontSize',FontsizeX)
ylabel('Erosion rate (km/Ga)', 'interpreter', 'latex','FontSize',FontsizeY)
set(gca,'FontSize',FontsizeInAxes)
set(gca, 'Layer', 'top')
print('-dpdf','Figure3_n1.4.pdf')
%!open Implications_3.pdf

