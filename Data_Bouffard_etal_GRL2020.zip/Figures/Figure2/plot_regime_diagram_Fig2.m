function [] = plot_regime_diagram_ML ()

close all

%--------------
% Commons
%--------------

cd ../
SetFigureDefaults_2
cd ./Figure2/

%--------------
% Enter DATA
%--------------

% All data are now in a big DATA array

DATA = define_data ();

Ra_crit_Ek15 = 5.18e-8;
Ra_crit_Ek35 = 3.34e-7;
Ra_crit_Ek14 = 2.61e-6;
Ra_crit_Ek34 = 1.72e-5;

DATA(:,9);
ndata = length(DATA(:,9))

for i = 1:ndata
   if (DATA(i,2) == 3e-4)
      Ra_crit(i) = Ra_crit_Ek34;
   elseif (DATA(i,2) == 1e-4)
      Ra_crit(i) = Ra_crit_Ek14;
   elseif (DATA(i,2) == 3e-5)
      Ra_crit(i) = Ra_crit_Ek35;
   elseif (DATA(i,2) == 1e-5)
      Ra_crit(i) = Ra_crit_Ek15;
   end
end

Ra_crit 

RaT_Omega = DATA(:,3).*DATA(:,2).^2;
RaC_Omega = DATA(:,4).*DATA(:,2);
Ri0 = (DATA(:,4)./(DATA(:,6).^2.*DATA(:,2)));

i_WLC = 0;
i_GEdd = 0;
i_GE = 0;

n_WLC = 0;
n_GEdd = 0;
n_GE = 0;

% Count how many points there are for each regime
for i = 1:ndata
    if DATA(i,9) == 1       % WLC
        n_WLC = n_WLC + 1;
    elseif DATA(i,9) == 2  % E+DDC
        n_GEdd = n_GEdd + 1;
    elseif DATA(i,9) == 3                   % E
        n_GE = n_GE + 1;
    end
end

n_WLC
n_GEdd
n_GE

RaT_WLC = zeros(1,n_WLC);
RaC_WLC = zeros(1,n_WLC);
N2_Omega2_WLC = zeros(1,n_WLC);
E_WLC = zeros(1,n_WLC);
Ri0_WLC = zeros(1,n_WLC);
RaT_Omega_WLC = zeros(1,n_WLC);
RaT_Omega_WLC = zeros(1,n_WLC);

RaT_GEdd = zeros(1,n_GEdd);
RaC_GEdd = zeros(1,n_GEdd);
N2_Omega2_GEdd = zeros(1,n_GEdd);
E_GEdd = zeros(1,n_GEdd);
Ri_0_GEdd = zeros(1,n_GEdd);
RaT_Omega_GEdd = zeros(1,n_GEdd);
RaC_Omega_GEdd = zeros(1,n_GEdd);

RaT_GE = zeros(1,n_GE);
RaC_GE = zeros(1,n_GE);
N2_Omega2_GE = zeros(1,n_GE);
E_GE = zeros(1,n_GE);
Ri0_GE = zeros(1,n_GE);
RaT_Omega_GE = zeros(1,n_GE);
RaC_Omega_GE = zeros(1,n_GE);

for i = 1:ndata
    if DATA(i,9) == 1       % WLC
        i_WLC = i_WLC + 1;
        RaT_WLC(i_WLC) = DATA(i,3);
        RaC_WLC(i_WLC) = DATA(i,4);
        N2_Omega2_WLC(i_WLC) = DATA(i,5);
        E_WLC(i_WLC) = DATA(i,2);
        Ri0_WLC(i_WLC) = Ri0(i);
        RaT_Omega_WLC(i_WLC) = RaT_Omega(i)/Ra_crit(i);
        RaC_Omega_WLC(i_WLC) = RaC_Omega(i);
    elseif DATA(i,9) == 2  % E+DDC
        i_GEdd = i_GEdd + 1;
        RaT_GEdd(i_GEdd) = DATA(i,3);
        RaC_GEdd(i_GEdd) = DATA(i,4);
        N2_Omega2_GEdd(i_GEdd) = DATA(i,5);
        E_GEdd(i_GEdd) = DATA(i,2);
        Ri0_GEdd(i_GEdd) = Ri0(i);
        RaT_Omega_GEdd(i_GEdd) = RaT_Omega(i)/Ra_crit(i);
        RaC_Omega_GEdd(i_GEdd) = RaC_Omega(i);
    elseif DATA(i,9) == 3                   % E
        i_GE = i_GE + 1;
        RaT_GE(i_GE) = DATA(i,3);
        RaC_GE(i_GE) = DATA(i,4);
        N2_Omega2_GE(i_GE) = DATA(i,5);
        E_GE(i_GE) = DATA(i,2);
        Ri0_GE(i_GE) = Ri0(i);
        RaT_Omega_GE(i_GE) = RaT_Omega(i)/Ra_crit(i);
        RaC_Omega_GE(i_GE) = RaC_Omega(i);
    end
end

RaT_WLC
RaT_GE
RaT_GEdd
Ri0_WLC
Ri0_GE
Ri0_GEdd

%RaT_WLC = [3e3 1e4 3e4 3e3 1e5];
%RaC_WLC = [2e1 1e2 5e2 3e1 1e3];
%Ro_WLC  = [1.54e-2 3.16e-2 4.36e-2 5.8e-3 2.22e-2];
%dRo_WLC = [];
%N2_Omega2_WLC = [2.73e-2 1.37e-1 6.83e-1 1.37e-2 1.37e-1];
%E_WLC  = [3e-4 3e-4 3e-4 1e-4 3e-5];

%RaT_GE = [3e3 3e3 3e3 3e3 1e4 1e4 1e4 3e4 3e4 3e4 3e3 3e3 3e3 3e3 3e3 3e4];
%RaC_GE = [1e2 3e2 1e3 3e3 3e2 1e3 3e3 5e3 2e4 5e4 1e2 2e2 3e2 3e3 1e4 2e3];
%Ro_GE = [1.49e-2 1.23e-2 1e-2 9.3e-3 3.09e-2 2.73e-2 2.81e-2 3.63e-2 3.93e-2 3.76e-2 5.86e-3 4.94e-3 5.2e-3 3.4e-3 2.9e-3 2.22e-2];
%dRo_GE = [];
%N2_Omega2_GE = [1.37e-1 4.1e-1 1.37 4.1 4.1e-1 1.37 4.1 6.83 2.73e1 6.83e1 4.55e-2 9.1e-2 1.37e-1 1.37 4.55 9.1e-1];
%E_GE  = [3e-4 3e-4 3e-4 3e-4 3e-4 3e-4 3e-4 3e-4 3e-4 3e-4 1e-4 1e-4 1e-4 1e-4 1e-4 1e-4];

%RaT_GEdd = [2e4 5e4 1e5 5e4];
%RaC_GEdd = [5e2 2e3 5e3 1e3];
%Ro_GEdd = [5.2e-3 9.9e-3 1.84e-2 9.5e-3];
%N2_Omega2_GEdd = [6.83e-2 2.73e-1 6.83e-1 1.37e-1];
%E_GEdd = [3e-5 3e-5 3e-5 3e-5]
h0 = 0.2;

BR_WLC = RaC_WLC./RaT_WLC./h0;
BR_GE = RaC_GE./RaT_GE./h0;
BR_GEdd = RaC_GEdd./RaT_GEdd./h0;

%BR_Earth_min = 1;
%BR_Earth_max = 100;
%Ro_Earth_min = 1e-6;
%Ro_Earth_max = 3e-6;


%--------------
% PLOT
%--------------


%--------------
% Version a, N/Omega
%--------------


f1 = figure(1)
% Place simulations
scatter(N2_Omega2_WLC.^(1/2),BR_WLC,Markersize,MarkerWLC,...
               'MarkerEdgeColor',c_markeredge,...
               'MarkerFaceColor',c_RegimeWholeLayer,'LineWidth',MarkerLinewidth);
           hold on
scatter(N2_Omega2_GE.^(1/2),BR_GE,Markersize,MarkerGE,...
            'MarkerEdgeColor',c_markeredge,...
            'MarkerFaceColor',c_RegimeErosion,'LineWidth',MarkerLinewidth);
scatter(N2_Omega2_GEdd.^(1/2),BR_GEdd,Markersize,MarkerGEdd,...
            'MarkerEdgeColor',c_markeredge,...
            'MarkerFaceColor',c_RegimeErosion,'LineWidth',MarkerLinewidth)
        
% ERROR BARS AS WELL??

% Add the Earth
%width = Ro_Earth_max-Ro_Earth_min; % whatever
%height = BR_Earth_max-BR_Earth_min; % whatever...
%xCenter = (Ro_Earth_min+Ro_Earth_max)*0.5; % Wherever...
%yCenter = (BR_Earth_min+BR_Earth_max)*0.5; % Wherever...
%xLeft = xCenter - width/2;
%yBottom = yCenter - height/2;
%rectangle('Position', [xLeft, yBottom, width, height], 'EdgeColor', 'k', 'FaceColor', 'm', 'LineWidth', 3);

grid on;

% Set grid
x_min = 0.001;
x_max = 100;

xlim([0.05 20])
ylim([0.005./h0 30./h0])

set(gca,'xscale','log','yscale','log')
xlabel('Stratification to rotation, $N/\Omega$', 'interpreter', Inter,'FontSize',FontsizeX)
ylabel('Buoyancy ratio, $B^*$','interpreter', Inter,'FontSize',FontsizeY)
set(gca,'FontSize',FontsizeInAxes)

% Add line separating regimes, below symbols
x = linspace(x_min,x_max,1000);
a = -0.;
b = 0.018./h0;
y = b*x.^a;
plot(x,y,LineType_regime,'LineWidth',Linewidth_regime,'Color',LineC_erosion)
b = 0.058./h0;
y = b*x.^a;
plot(x,y,LineType_regime,'LineWidth',Linewidth_regime,'Color',LineC_erosion)

% Place simulations on top
scatter(N2_Omega2_WLC.^(1/2),BR_WLC,Markersize,MarkerWLC,...
               'MarkerEdgeColor',c_markeredge,...
               'MarkerFaceColor',c_RegimeWholeLayer,'LineWidth',MarkerLinewidth);
scatter(N2_Omega2_GE.^(1/2),BR_GE,Markersize,MarkerGE,...
            'MarkerEdgeColor',c_markeredge,...
            'MarkerFaceColor',c_RegimeErosion,'LineWidth',MarkerLinewidth);
scatter(N2_Omega2_GEdd.^(1/2),BR_GEdd,Markersize,MarkerGEdd,...
            'MarkerEdgeColor',c_markeredge,...
            'MarkerFaceColor',c_RegimeErosion,'LineWidth',MarkerLinewidth)
        
pbaspect([1 1 1]);
l = legend('Whole-layer','Erosion','Erosion with layering')
set(l, 'interpreter', Inter,'FontSize',FontsizeInFig)
set(f1,'Position',FigSize1);
print('-dpdf','Figure_2_a.pdf')



%--------------
% Version b, RaT
%--------------

f2 = figure(2)
% Place simulations
scatter(RaT_WLC.*E_WLC.^2,BR_WLC,Markersize,MarkerWLC,...
              'MarkerEdgeColor',c_markeredge,...
               'MarkerFaceColor',c_RegimeWholeLayer,'LineWidth',MarkerLinewidth);
hold on;
scatter(RaT_GE.*E_GE.^2,BR_GE,Markersize,MarkerGE,...
            'MarkerEdgeColor',c_markeredge,...
            'MarkerFaceColor',c_RegimeErosion,'LineWidth',MarkerLinewidth);
scatter(RaT_GEdd.*E_GEdd.^2,BR_GEdd,Markersize,MarkerGEdd,...
            'MarkerEdgeColor',c_markeredge,...
            'MarkerFaceColor',c_RegimeErosion,'LineWidth',MarkerLinewidth)
        
% ERROR BARS AS WELL??

% Add the Earth
%width = Ro_Earth_max-Ro_Earth_min; % whatever
%height = BR_Earth_max-BR_Earth_min; % whatever...
%xCenter = (Ro_Earth_min+Ro_Earth_max)*0.5; % Wherever...
%yCenter = (BR_Earth_min+BR_Earth_max)*0.5; % Wherever...
%xLeft = xCenter - width/2;
%yBottom = yCenter - height/2;
%rectangle('Position', [xLeft, yBottom, width, height], 'EdgeColor', 'k', 'FaceColor', 'm', 'LineWidth', 3);

grid on;

% Set grid
x_min = 8e-7;
x_max = 1;

xlim([8e-7 1e-2])
ylim([0.002./h0 30./h0])

set(gca,'xscale','log','yscale','log')

xlabel('Strength of convection, $Ra_T$', 'interpreter', Inter,'FontSize',FontsizeX)
ylabel('Buoyancy ratio, $B^*$','interpreter',Inter,'FontSize',FontsizeY)
set(gca,'FontSize',FontsizeInAxes)

% Add line separating regimes, below symbols
x = linspace(x_min,x_max,1000);
a = -0.;
b = 0.018./h0;
y = b*x.^a;
plot(x,y,LineType_regime,'LineWidth',Linewidth_regime,'Color',LineC_erosion)
b = 0.058./h0;
y = b*x.^a;
plot(x,y,LineType_regime,'LineWidth',Linewidth_regime,'Color',LineC_erosion)

% Place simulations on top    
scatter(RaT_WLC.*E_WLC.^2,BR_WLC,Markersize,MarkerWLC,...
              'MarkerEdgeColor',c_markeredge,...
               'MarkerFaceColor',c_RegimeWholeLayer,'LineWidth',MarkerLinewidth);
scatter(RaT_GE.*E_GE.^2,BR_GE,Markersize,MarkerGE,...
            'MarkerEdgeColor',c_markeredge,...
            'MarkerFaceColor',c_RegimeErosion,'LineWidth',MarkerLinewidth);
scatter(RaT_GEdd.*E_GEdd.^2,BR_GEdd,Markersize,MarkerGEdd,...
            'MarkerEdgeColor',c_markeredge,...
            'MarkerFaceColor',c_RegimeErosion,'LineWidth',MarkerLinewidth)
        
pbaspect([1 1 1]);
box on;
l = legend('Whole-layer','Erosion with DDC','Erosion without DDC')
set(l, 'interpreter', Inter,'FontSize',FontsizeInFig)
set(f2,'Position',FigSize1);
print('-dpdf','Figure_2_b.pdf')








f3 = figure(3)
% Place simulations
scatter(Ri0_WLC,RaT_Omega_WLC,Markersize,MarkerWLC,...
              'MarkerEdgeColor',c_markeredge,...
              'MarkerFaceColor',c_RegimeWholeLayer,'LineWidth',MarkerLinewidth);
hold on;
scatter(Ri0_GE,RaT_Omega_GE,Markersize,MarkerGE,...
            'MarkerEdgeColor',c_markeredge,...
            'MarkerFaceColor',c_RegimeErosion,'LineWidth',MarkerLinewidth);
scatter(Ri0_GEdd,RaT_Omega_GEdd,Markersize,MarkerGEdd,...
            'MarkerEdgeColor',c_markeredge,...
            'MarkerFaceColor',c_RegimeErosion,'LineWidth',MarkerLinewidth)

% ERROR BARS AS WELL??

% Add the Earth
%width = Ro_Earth_max-Ro_Earth_min; % whatever
%height = BR_Earth_max-BR_Earth_min; % whatever...
%xCenter = (Ro_Earth_min+Ro_Earth_max)*0.5; % Wherever...
%yCenter = (BR_Earth_min+BR_Earth_max)*0.5; % Wherever...
%xLeft = xCenter - width/2;
%yBottom = yCenter - height/2;
%rectangle('Position', [xLeft, yBottom, width, height], 'EdgeColor', 'k', 'FaceColor', 'm', 'LineWidth', 3);

grid on;


% Set grid
x_min = 10;
x_max = 2e5;
y_min = 7;
y_max = 400;

xlim([x_min x_max])
ylim([y_min y_max])

set(gca,'xscale','log','yscale','log')

ylabel('Strength of convection, $Ra_T/Ra_{T,c}$', 'interpreter', Inter,'FontSize',FontsizeX)
xlabel('Richardson number, $Ri_0$','interpreter',Inter,'FontSize',FontsizeY)
set(gca,'FontSize',FontsizeInAxes)

% Add line separating regimes, below symbols
y = linspace(y_min,y_max,1000);
x = 93*ones(1000);
plot(x,y,LineType_regime,'LineWidth',Linewidth_regime,'Color',LineC_erosion)
%b = 0.058./h0;
%y = b*x.^a;
%plot(x,y,LineType_regime,'LineWidth',Linewidth_regime,'Color',LineC_erosion)

% Place simulations on top
scatter(Ri0_WLC,RaT_Omega_WLC,Markersize,MarkerWLC,...
              'MarkerEdgeColor',c_markeredge,...
               'MarkerFaceColor',c_RegimeWholeLayer,'LineWidth',MarkerLinewidth);
scatter(Ri0_GE,RaT_Omega_GE,Markersize,MarkerGE,...
            'MarkerEdgeColor',c_markeredge,...
            'MarkerFaceColor',c_RegimeErosion,'LineWidth',MarkerLinewidth);
scatter(Ri0_GEdd,RaT_Omega_GEdd,Markersize,MarkerGEdd,...
            'MarkerEdgeColor',c_markeredge,...
            'MarkerFaceColor',c_RegimeErosion,'LineWidth',MarkerLinewidth)

pbaspect([1 1 1]);
box on;
%l = legend('Whole layer convection','Erosion','Erosion with double-diffusive convection')%,'Location','southeast')
%set(l, 'interpreter', Inter,'FontSize',FontsizeInFig,'Location','east')
set(f3,'Position',FigSize1);
print('-dpdf','Figure_2_c.pdf')

end
